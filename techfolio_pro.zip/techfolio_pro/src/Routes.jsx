import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import SkillsMatrixPage from './pages/skills-matrix-dynamic-technical-capabilities';
import ProjectsShowcase from './pages/projects-showcase-interactive-portfolio-gallery';
import AboutSectionProfessionalBrandStory from './pages/about-section-professional-brand-story';
import ContactBridgePage from './pages/contact-bridge-professional-connection-hub';
import HomepageInteractiveItPortfolio from './pages/homepage-interactive-it-portfolio';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<AboutSectionProfessionalBrandStory />} />
        <Route path="/skills-matrix-dynamic-technical-capabilities" element={<SkillsMatrixPage />} />
        <Route path="/projects-showcase-interactive-portfolio-gallery" element={<ProjectsShowcase />} />
        <Route path="/about-section-professional-brand-story" element={<AboutSectionProfessionalBrandStory />} />
        <Route path="/contact-bridge-professional-connection-hub" element={<ContactBridgePage />} />
        <Route path="/homepage-interactive-it-portfolio" element={<HomepageInteractiveItPortfolio />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
