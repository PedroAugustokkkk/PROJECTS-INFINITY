import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const SkillCard = ({ skill, index, isHovered, onHover, categoryColor }) => {
  const getProficiencyColor = (level) => {
    if (level >= 90) return 'text-green-600';
    if (level >= 75) return 'text-blue-600';
    if (level >= 60) return 'text-yellow-600';
    return 'text-orange-600';
  };

  const getProficiencyLabel = (level) => {
    if (level >= 90) return 'Especialista';
    if (level >= 75) return 'Avançado';
    if (level >= 60) return 'Intermediário';
    return 'Básico';
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      whileHover={{ scale: 1.02, y: -2 }}
      onHoverStart={() => onHover(skill?.name)}
      onHoverEnd={() => onHover(null)}
      className="bg-background rounded-lg border border-border p-4 hover:shadow-brand transition-all duration-300 cursor-pointer group"
    >
      {/* Skill Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={`w-8 h-8 rounded-md bg-gradient-to-r ${categoryColor} flex items-center justify-center`}>
            <span className="text-white text-xs font-bold">
              {skill?.name?.substring(0, 2)?.toUpperCase()}
            </span>
          </div>
          <div>
            <h4 className="font-semibold text-foreground group-hover:text-brand-primary transition-colors">
              {skill?.name}
            </h4>
            <p className="text-xs text-muted-foreground">
              {skill?.experience} anos • {skill?.projects} projetos
            </p>
          </div>
        </div>
        {skill?.isNew && (
          <div className="bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full font-medium">
            Novo
          </div>
        )}
      </div>
      {/* Proficiency Bar */}
      <div className="mb-3">
        <div className="flex items-center justify-between mb-1">
          <span className={`text-sm font-medium ${getProficiencyColor(skill?.proficiency)}`}>
            {getProficiencyLabel(skill?.proficiency)}
          </span>
          <span className="text-sm text-muted-foreground">
            {skill?.proficiency}%
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${skill?.proficiency}%` }}
            transition={{ duration: 1, delay: index * 0.1 }}
            className={`h-2 rounded-full bg-gradient-to-r ${categoryColor}`}
          />
        </div>
      </div>
      {/* Skill Details */}
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ 
          opacity: isHovered ? 1 : 0, 
          height: isHovered ? 'auto' : 0 
        }}
        transition={{ duration: 0.2 }}
        className="overflow-hidden"
      >
        <div className="pt-2 border-t border-border">
          {skill?.frameworks && (
            <div className="mb-2">
              <p className="text-xs text-muted-foreground mb-1">Frameworks/Libs:</p>
              <div className="flex flex-wrap gap-1">
                {skill?.frameworks?.map((framework, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded"
                  >
                    {framework}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {skill?.certifications && skill?.certifications?.length > 0 && (
            <div className="mb-2">
              <p className="text-xs text-muted-foreground mb-1">Certificações:</p>
              <div className="flex items-center space-x-1">
                <Icon name="Award" size={12} className="text-accent" />
                <span className="text-xs text-foreground">
                  {skill?.certifications?.join(', ')}
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Última atualização: {skill?.lastUsed}</span>
            {skill?.trending && (
              <div className="flex items-center space-x-1 text-green-600">
                <Icon name="TrendingUp" size={12} />
                <span>Em alta</span>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default SkillCard;