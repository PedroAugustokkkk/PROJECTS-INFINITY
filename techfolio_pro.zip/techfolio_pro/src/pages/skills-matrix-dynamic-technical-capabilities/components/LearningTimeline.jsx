import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const LearningTimeline = () => {
  const timelineData = [
    {
      year: '2025',
      status: 'planned',
      title: 'Próximas Metas',
      skills: ['Rust', 'WebAssembly', 'Machine Learning', 'Blockchain'],
      description: 'Expandindo conhecimentos em tecnologias emergentes e especializações avançadas.',
      icon: 'Target'
    },
    {
      year: '2024',
      status: 'current',
      title: 'Aprendizado Atual',
      skills: ['Next.js 14', 'TypeScript Advanced', 'Microservices', 'Kubernetes'],
      description: 'Aprofundando conhecimentos em arquiteturas modernas e desenvolvimento full-stack.',
      icon: 'BookOpen'
    },
    {
      year: '2023',
      status: 'completed',
      title: 'Conquistas Recentes',
      skills: ['React 18', 'Node.js', 'MongoDB', 'AWS'],
      description: 'Consolidação de conhecimentos em desenvolvimento web moderno e cloud computing.',
      icon: 'CheckCircle'
    },
    {
      year: '2022',
      status: 'completed',
      title: 'Fundamentos Sólidos',
      skills: ['JavaScript ES6+', 'Python', 'SQL', 'Git'],
      description: 'Estabelecimento de base sólida em programação e versionamento de código.',
      icon: 'Code'
    },
    {
      year: '2021',
      status: 'completed',
      title: 'Início da Jornada',
      skills: ['HTML5', 'CSS3', 'JavaScript', 'Responsive Design'],
      description: 'Primeiros passos no desenvolvimento web com foco em front-end.',
      icon: 'Play'
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'planned':
        return 'border-yellow-500 bg-yellow-50';
      case 'current':
        return 'border-blue-500 bg-blue-50';
      case 'completed':
        return 'border-green-500 bg-green-50';
      default:
        return 'border-gray-300 bg-gray-50';
    }
  };

  const getIconColor = (status) => {
    switch (status) {
      case 'planned':
        return 'text-yellow-600';
      case 'current':
        return 'text-blue-600';
      case 'completed':
        return 'text-green-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-card rounded-2xl border border-border p-8"
    >
      {/* Header */}
      <div className="text-center mb-8">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="w-16 h-16 bg-gradient-brand rounded-full flex items-center justify-center mx-auto mb-4"
        >
          <Icon name="Clock" size={32} className="text-white" />
        </motion.div>
        <h3 className="text-2xl font-heading font-bold text-foreground mb-2">
          Linha do Tempo de Aprendizado
        </h3>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Uma jornada contínua de crescimento e evolução técnica, mostrando a progressão 
          das habilidades ao longo dos anos.
        </p>
      </div>
      {/* Timeline */}
      <div className="relative">
        {/* Vertical Line */}
        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-accent via-brand-primary to-muted"></div>

        {/* Timeline Items */}
        <div className="space-y-8">
          {timelineData?.map((item, index) => (
            <motion.div
              key={item?.year}
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative flex items-start space-x-6"
            >
              {/* Timeline Dot */}
              <div className={`relative z-10 w-16 h-16 rounded-full border-4 ${getStatusColor(item?.status)} flex items-center justify-center shadow-soft`}>
                <Icon name={item?.icon} size={24} className={getIconColor(item?.status)} />
              </div>

              {/* Content */}
              <div className="flex-1 pb-8">
                <div className="bg-background rounded-lg border border-border p-6 shadow-soft hover:shadow-brand transition-shadow duration-300">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="text-xl font-semibold text-foreground">
                        {item?.title}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {item?.year}
                      </p>
                    </div>
                    {item?.status === 'current' && (
                      <div className="bg-accent text-accent-foreground text-xs px-3 py-1 rounded-full font-medium animate-pulse">
                        Em Progresso
                      </div>
                    )}
                    {item?.status === 'planned' && (
                      <div className="bg-yellow-100 text-yellow-800 text-xs px-3 py-1 rounded-full font-medium">
                        Planejado
                      </div>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {item?.description}
                  </p>

                  {/* Skills */}
                  <div className="flex flex-wrap gap-2">
                    {item?.skills?.map((skill, skillIndex) => (
                      <motion.span
                        key={skill}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: (index * 0.1) + (skillIndex * 0.05) }}
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          item?.status === 'current' ?'bg-blue-100 text-blue-800' 
                            : item?.status === 'planned' ?'bg-yellow-100 text-yellow-800' :'bg-green-100 text-green-800'
                        }`}
                      >
                        {skill}
                      </motion.span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="mt-8 pt-8 border-t border-border"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-brand-primary mb-1">4+</div>
            <div className="text-sm text-muted-foreground">Anos de Experiência</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-brand-primary mb-1">25+</div>
            <div className="text-sm text-muted-foreground">Tecnologias Dominadas</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-brand-primary mb-1">∞</div>
            <div className="text-sm text-muted-foreground">Vontade de Aprender</div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default LearningTimeline;