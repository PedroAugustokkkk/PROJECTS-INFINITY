import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const TechPhilosophy = () => {
  const philosophyPrinciples = [
    {
      icon: 'Target',
      title: 'Foco na Solução',
      description: 'Escolho tecnologias baseadas no problema a ser resolvido, não apenas nas tendências do momento.'
    },
    {
      icon: 'Zap',
      title: 'Performance First',
      description: 'Priorizo soluções que oferecem a melhor experiência do usuário com performance otimizada.'
    },
    {
      icon: 'Users',
      title: 'Colaboração',
      description: 'Valorizo tecnologias que facilitam o trabalho em equipe e a manutenibilidade do código.'
    },
    {
      icon: 'BookOpen',
      title: 'Aprendizado Contínuo',
      description: 'Mantenho-me atualizado com as últimas tendências, mas avalio criticamente antes de adotar.'
    }
  ];

  const learningApproach = [
    'Documentação oficial como fonte primária',
    'Projetos práticos para consolidar conhecimento',
    'Participação ativa na comunidade tech',
    'Mentoria e compartilhamento de conhecimento'
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-gradient-to-br from-brand-primary to-brand-secondary rounded-2xl p-8 text-white relative overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-4 right-4 w-32 h-32 border border-white/20 rounded-full"></div>
        <div className="absolute bottom-4 left-4 w-24 h-24 border border-white/20 rounded-full"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 border border-white/10 rounded-full"></div>
      </div>
      <div className="relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4"
          >
            <Icon name="Lightbulb" size={32} className="text-accent-foreground" />
          </motion.div>
          <h3 className="text-2xl font-heading font-bold mb-2">
            Filosofia Tecnológica
          </h3>
          <p className="text-white/80 max-w-2xl mx-auto">
            Minha abordagem para seleção e adoção de tecnologias é baseada em princípios sólidos 
            que priorizam eficiência, qualidade e impacto real nos projetos.
          </p>
        </div>

        {/* Philosophy Principles */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {philosophyPrinciples?.map((principle, index) => (
            <motion.div
              key={principle?.title}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
              className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20"
            >
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name={principle?.icon} size={24} className="text-accent-foreground" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">{principle?.title}</h4>
                  <p className="text-white/80 text-sm leading-relaxed">
                    {principle?.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Learning Approach */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20"
        >
          <div className="flex items-center space-x-3 mb-4">
            <Icon name="Compass" size={24} className="text-accent" />
            <h4 className="font-semibold text-lg">Metodologia de Aprendizado</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {learningApproach?.map((approach, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.8 + index * 0.1 }}
                className="flex items-center space-x-3"
              >
                <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0"></div>
                <span className="text-white/90 text-sm">{approach}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quote */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 1 }}
          className="text-center mt-8"
        >
          <blockquote className="text-lg italic text-white/90 max-w-3xl mx-auto">
            "A tecnologia é apenas uma ferramenta. O que realmente importa é como usamos 
            essa ferramenta para resolver problemas reais e criar valor para as pessoas."
          </blockquote>
          <div className="flex items-center justify-center space-x-2 mt-4">
            <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
              <span className="text-accent-foreground font-bold text-sm">TP</span>
            </div>
            <span className="text-white/80 text-sm">TechFolio Pro</span>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default TechPhilosophy;