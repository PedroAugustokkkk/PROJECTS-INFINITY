import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import SkillCard from './SkillCard';

const SkillCategory = ({ category, isExpanded, onToggle, index }) => {
  const [hoveredSkill, setHoveredSkill] = useState(null);

  const categoryIcons = {
    'Frontend': 'Monitor',
    'Backend': 'Server',
    'Database': 'Database',
    'DevOps & Cloud': 'Cloud',
    'Mobile': 'Smartphone',
    'Tools & Others': 'Wrench'
  };

  const categoryColors = {
    'Frontend': 'from-blue-500 to-cyan-500',
    'Backend': 'from-green-500 to-emerald-500',
    'Database': 'from-purple-500 to-violet-500',
    'DevOps & Cloud': 'from-orange-500 to-red-500',
    'Mobile': 'from-pink-500 to-rose-500',
    'Tools & Others': 'from-yellow-500 to-amber-500'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-card rounded-xl border border-border shadow-soft overflow-hidden"
    >
      {/* Category Header */}
      <button
        onClick={onToggle}
        className="w-full p-6 flex items-center justify-between hover:bg-muted/50 transition-colors"
      >
        <div className="flex items-center space-x-4">
          <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${categoryColors?.[category?.name]} flex items-center justify-center shadow-soft`}>
            <Icon name={categoryIcons?.[category?.name]} size={24} color="white" />
          </div>
          <div className="text-left">
            <h3 className="text-xl font-heading font-bold text-foreground">
              {category?.name}
            </h3>
            <p className="text-sm text-muted-foreground">
              {category?.skills?.length} tecnologias • {category?.totalExperience} anos de experiência
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <div className="text-right">
            <div className="text-sm font-medium text-foreground">
              Nível Médio: {category?.averageLevel}%
            </div>
            <div className="text-xs text-muted-foreground">
              {category?.totalProjects} projetos
            </div>
          </div>
          <motion.div
            animate={{ rotate: isExpanded ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <Icon name="ChevronDown" size={20} className="text-muted-foreground" />
          </motion.div>
        </div>
      </button>
      {/* Skills Grid */}
      <motion.div
        initial={false}
        animate={{ height: isExpanded ? 'auto' : 0 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="overflow-hidden"
      >
        <div className="p-6 pt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {category?.skills?.map((skill, skillIndex) => (
              <SkillCard
                key={skill?.name}
                skill={skill}
                index={skillIndex}
                isHovered={hoveredSkill === skill?.name}
                onHover={setHoveredSkill}
                categoryColor={categoryColors?.[category?.name]}
              />
            ))}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default SkillCategory;