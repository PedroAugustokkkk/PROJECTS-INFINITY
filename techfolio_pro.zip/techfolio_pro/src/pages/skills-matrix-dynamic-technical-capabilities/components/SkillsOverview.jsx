import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const SkillsOverview = () => {
  const overviewStats = [
    {
      icon: 'Code',
      label: 'Linguagens',
      value: '8+',
      description: 'JavaScript, TypeScript, Python, Java, C#, PHP, SQL, HTML/CSS',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: 'Layers',
      label: 'Frameworks',
      value: '12+',
      description: 'React, Next.js, Node.js, Express, Django, Spring Boot, .NET',
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: 'Database',
      label: 'Databases',
      value: '6+',
      description: 'MongoDB, PostgreSQL, MySQL, Redis, Firebase, Supabase',
      color: 'from-purple-500 to-violet-500'
    },
    {
      icon: 'Cloud',
      label: 'Cloud & DevOps',
      value: '10+',
      description: 'AWS, Docker, Kubernetes, CI/CD, Terraform, Nginx',
      color: 'from-orange-500 to-red-500'
    }
  ];

  const expertiseAreas = [
    {
      title: 'Full-Stack Development',
      level: 95,
      description: 'Desenvolvimento completo de aplicações web modernas'
    },
    {
      title: 'Frontend Architecture',
      level: 92,
      description: 'Arquitetura e otimização de interfaces de usuário'
    },
    {
      title: 'Backend Systems',
      level: 88,
      description: 'APIs RESTful, microserviços e arquiteturas escaláveis'
    },
    {
      title: 'Database Design',
      level: 85,
      description: 'Modelagem e otimização de bancos de dados'
    },
    {
      title: 'DevOps & Cloud',
      level: 80,
      description: 'Deploy, monitoramento e infraestrutura como código'
    },
    {
      title: 'Mobile Development',
      level: 75,
      description: 'Aplicações móveis híbridas e nativas'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >
      {/* Header */}
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="w-20 h-20 bg-gradient-brand rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-brand"
        >
          <Icon name="Zap" size={40} className="text-white" />
        </motion.div>
        <h2 className="text-4xl font-heading font-bold text-foreground mb-4">
          Matriz de Habilidades Técnicas
        </h2>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          Uma visão abrangente das minhas competências técnicas, organizadas por categoria 
          e nível de proficiência. Cada habilidade reflete anos de experiência prática 
          e projetos reais desenvolvidos.
        </p>
      </div>
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {overviewStats?.map((stat, index) => (
          <motion.div
            key={stat?.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
            className="bg-card rounded-xl border border-border p-6 hover:shadow-brand transition-all duration-300 hover-lift group"
          >
            <div className="flex items-center space-x-4 mb-4">
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${stat?.color} flex items-center justify-center shadow-soft group-hover:scale-110 transition-transform duration-300`}>
                <Icon name={stat?.icon} size={24} color="white" />
              </div>
              <div>
                <div className="text-2xl font-bold text-foreground">{stat?.value}</div>
                <div className="text-sm font-medium text-muted-foreground">{stat?.label}</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {stat?.description}
            </p>
          </motion.div>
        ))}
      </div>
      {/* Expertise Areas */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="bg-card rounded-2xl border border-border p-8"
      >
        <div className="flex items-center space-x-3 mb-8">
          <Icon name="BarChart3" size={28} className="text-brand-primary" />
          <h3 className="text-2xl font-heading font-bold text-foreground">
            Áreas de Especialização
          </h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {expertiseAreas?.map((area, index) => (
            <motion.div
              key={area?.title}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
              className="space-y-3"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-foreground">{area?.title}</h4>
                <span className="text-sm font-medium text-brand-primary">
                  {area?.level}%
                </span>
              </div>
              
              <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${area?.level}%` }}
                  transition={{ duration: 1.5, delay: 0.8 + index * 0.1, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-brand-primary to-accent rounded-full relative"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse"></div>
                </motion.div>
              </div>
              
              <p className="text-sm text-muted-foreground">
                {area?.description}
              </p>
            </motion.div>
          ))}
        </div>
      </motion.div>
      {/* Quick Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1 }}
        className="bg-gradient-to-r from-brand-primary to-brand-secondary rounded-2xl p-8 text-white"
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <div className="text-3xl font-bold mb-2">50+</div>
            <div className="text-sm opacity-90">Projetos Concluídos</div>
          </div>
          <div>
            <div className="text-3xl font-bold mb-2">4+</div>
            <div className="text-sm opacity-90">Anos de Experiência</div>
          </div>
          <div>
            <div className="text-3xl font-bold mb-2">25+</div>
            <div className="text-sm opacity-90">Tecnologias</div>
          </div>
          <div>
            <div className="text-3xl font-bold mb-2">100%</div>
            <div className="text-sm opacity-90">Dedicação</div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default SkillsOverview;