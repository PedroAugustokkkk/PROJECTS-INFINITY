import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import SkillsOverview from './components/SkillsOverview';
import SkillCategory from './components/SkillCategory';
import TechPhilosophy from './components/TechPhilosophy';
import LearningTimeline from './components/LearningTimeline';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const SkillsMatrixPage = () => {
  const [expandedCategories, setExpandedCategories] = useState({});
  const [filterLevel, setFilterLevel] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock skills data organized by categories
  const skillsData = [
    {
      name: 'Frontend',
      totalExperience: 4,
      averageLevel: 92,
      totalProjects: 35,
      skills: [
        {
          name: 'React',
          proficiency: 95,
          experience: 3,
          projects: 25,
          frameworks: ['Next.js', 'Gatsby', 'Create React App'],
          certifications: ['React Developer Certification'],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'TypeScript',
          proficiency: 90,
          experience: 2,
          projects: 20,
          frameworks: ['React', 'Node.js', 'Angular'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Next.js',
          proficiency: 88,
          experience: 2,
          projects: 15,
          frameworks: ['App Router', 'Pages Router', 'Vercel'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: true
        },
        {
          name: 'Vue.js',
          proficiency: 75,
          experience: 1,
          projects: 8,
          frameworks: ['Nuxt.js', 'Vuetify', 'Quasar'],
          certifications: [],
          lastUsed: 'Novembro 2024',
          trending: false,
          isNew: false
        },
        {
          name: 'Tailwind CSS',
          proficiency: 92,
          experience: 2,
          projects: 30,
          frameworks: ['Headless UI', 'Tailwind UI'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Sass/SCSS',
          proficiency: 85,
          experience: 3,
          projects: 18,
          frameworks: ['Bootstrap', 'Foundation'],
          certifications: [],
          lastUsed: 'Outubro 2024',
          trending: false,
          isNew: false
        }
      ]
    },
    {
      name: 'Backend',
      totalExperience: 3,
      averageLevel: 87,
      totalProjects: 28,
      skills: [
        {
          name: 'Node.js',
          proficiency: 90,
          experience: 3,
          projects: 22,
          frameworks: ['Express.js', 'Fastify', 'NestJS'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Python',
          proficiency: 85,
          experience: 2,
          projects: 15,
          frameworks: ['Django', 'Flask', 'FastAPI'],
          certifications: ['Python Institute PCAP'],
          lastUsed: 'Novembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Express.js',
          proficiency: 88,
          experience: 3,
          projects: 20,
          frameworks: ['Middleware', 'REST APIs', 'GraphQL'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'GraphQL',
          proficiency: 78,
          experience: 1,
          projects: 8,
          frameworks: ['Apollo Server', 'Prisma', 'Relay'],
          certifications: [],
          lastUsed: 'Outubro 2024',
          trending: true,
          isNew: true
        },
        {
          name: 'REST APIs',
          proficiency: 92,
          experience: 3,
          projects: 25,
          frameworks: ['OpenAPI', 'Swagger', 'Postman'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        }
      ]
    },
    {
      name: 'Database',
      totalExperience: 3,
      averageLevel: 83,
      totalProjects: 22,
      skills: [
        {
          name: 'MongoDB',
          proficiency: 88,
          experience: 2,
          projects: 18,
          frameworks: ['Mongoose', 'Atlas', 'Compass'],
          certifications: ['MongoDB Developer'],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'PostgreSQL',
          proficiency: 85,
          experience: 2,
          projects: 12,
          frameworks: ['Prisma', 'Sequelize', 'TypeORM'],
          certifications: [],
          lastUsed: 'Novembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'MySQL',
          proficiency: 80,
          experience: 3,
          projects: 15,
          frameworks: ['Workbench', 'phpMyAdmin'],
          certifications: [],
          lastUsed: 'Outubro 2024',
          trending: false,
          isNew: false
        },
        {
          name: 'Redis',
          proficiency: 75,
          experience: 1,
          projects: 8,
          frameworks: ['Redis CLI', 'RedisInsight'],
          certifications: [],
          lastUsed: 'Setembro 2024',
          trending: true,
          isNew: true
        },
        {
          name: 'Firebase',
          proficiency: 82,
          experience: 2,
          projects: 10,
          frameworks: ['Firestore', 'Realtime Database', 'Auth'],
          certifications: [],
          lastUsed: 'Novembro 2024',
          trending: true,
          isNew: false
        }
      ]
    },
    {
      name: 'DevOps & Cloud',
      totalExperience: 2,
      averageLevel: 78,
      totalProjects: 18,
      skills: [
        {
          name: 'AWS',
          proficiency: 82,
          experience: 2,
          projects: 12,
          frameworks: ['EC2', 'S3', 'Lambda', 'RDS'],
          certifications: ['AWS Cloud Practitioner'],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Docker',
          proficiency: 85,
          experience: 2,
          projects: 15,
          frameworks: ['Docker Compose', 'Dockerfile'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Kubernetes',
          proficiency: 70,
          experience: 1,
          projects: 5,
          frameworks: ['kubectl', 'Helm'],
          certifications: [],
          lastUsed: 'Outubro 2024',
          trending: true,
          isNew: true
        },
        {
          name: 'CI/CD',
          proficiency: 80,
          experience: 2,
          projects: 18,
          frameworks: ['GitHub Actions', 'GitLab CI', 'Jenkins'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Vercel',
          proficiency: 88,
          experience: 2,
          projects: 20,
          frameworks: ['Vercel CLI', 'Edge Functions'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        }
      ]
    },
    {
      name: 'Mobile',
      totalExperience: 2,
      averageLevel: 75,
      totalProjects: 12,
      skills: [
        {
          name: 'React Native',
          proficiency: 80,
          experience: 2,
          projects: 8,
          frameworks: ['Expo', 'React Navigation'],
          certifications: [],
          lastUsed: 'Novembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Flutter',
          proficiency: 70,
          experience: 1,
          projects: 4,
          frameworks: ['Dart', 'Material Design'],
          certifications: [],
          lastUsed: 'Setembro 2024',
          trending: true,
          isNew: true
        },
        {
          name: 'PWA',
          proficiency: 85,
          experience: 2,
          projects: 12,
          frameworks: ['Service Workers', 'Web App Manifest'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        }
      ]
    },
    {
      name: 'Tools & Others',
      totalExperience: 4,
      averageLevel: 88,
      totalProjects: 40,
      skills: [
        {
          name: 'Git',
          proficiency: 95,
          experience: 4,
          projects: 40,
          frameworks: ['GitHub', 'GitLab', 'Bitbucket'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'VS Code',
          proficiency: 92,
          experience: 4,
          projects: 40,
          frameworks: ['Extensions', 'Debugging', 'IntelliSense'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Figma',
          proficiency: 85,
          experience: 3,
          projects: 25,
          frameworks: ['Prototyping', 'Design Systems'],
          certifications: [],
          lastUsed: 'Dezembro 2024',
          trending: true,
          isNew: false
        },
        {
          name: 'Webpack',
          proficiency: 78,
          experience: 2,
          projects: 15,
          frameworks: ['Babel', 'ESLint', 'Prettier'],
          certifications: [],
          lastUsed: 'Outubro 2024',
          trending: false,
          isNew: false
        },
        {
          name: 'Jest',
          proficiency: 82,
          experience: 2,
          projects: 18,
          frameworks: ['React Testing Library', 'Enzyme'],
          certifications: [],
          lastUsed: 'Novembro 2024',
          trending: true,
          isNew: false
        }
      ]
    }
  ];

  // Initialize expanded categories
  useEffect(() => {
    const initialExpanded = {};
    skillsData?.forEach((category, index) => {
      initialExpanded[category.name] = index < 2; // Expand first 2 categories by default
    });
    setExpandedCategories(initialExpanded);
  }, []);

  const toggleCategory = (categoryName) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryName]: !prev?.[categoryName]
    }));
  };

  const expandAllCategories = () => {
    const allExpanded = {};
    skillsData?.forEach(category => {
      allExpanded[category.name] = true;
    });
    setExpandedCategories(allExpanded);
  };

  const collapseAllCategories = () => {
    const allCollapsed = {};
    skillsData?.forEach(category => {
      allCollapsed[category.name] = false;
    });
    setExpandedCategories(allCollapsed);
  };

  const filteredSkillsData = skillsData?.map(category => ({
    ...category,
    skills: category?.skills?.filter(skill => {
      const matchesSearch = skill?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase());
      const matchesLevel = filterLevel === 'all' || 
        (filterLevel === 'expert' && skill?.proficiency >= 90) ||
        (filterLevel === 'advanced' && skill?.proficiency >= 75 && skill?.proficiency < 90) ||
        (filterLevel === 'intermediate' && skill?.proficiency >= 60 && skill?.proficiency < 75) ||
        (filterLevel === 'beginner' && skill?.proficiency < 60);
      
      return matchesSearch && matchesLevel;
    })
  }))?.filter(category => category?.skills?.length > 0);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Habilidades Técnicas - TechFolio Pro | Matriz de Competências</title>
        <meta name="description" content="Explore minhas habilidades técnicas organizadas por categoria: Frontend, Backend, Database, DevOps & Cloud, Mobile e Tools. Visualização interativa com níveis de proficiência e experiência prática." />
        <meta name="keywords" content="habilidades técnicas, competências, React, Node.js, Python, AWS, Docker, desenvolvimento web, programação" />
        <meta property="og:title" content="Habilidades Técnicas - TechFolio Pro" />
        <meta property="og:description" content="Matriz interativa de habilidades técnicas com mais de 25 tecnologias organizadas por categoria e nível de proficiência." />
        <meta property="og:type" content="website" />
      </Helmet>
      <Header />
      <main className="pt-16">
        {/* Skills Overview Section */}
        <section className="py-20 px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <SkillsOverview />
          </div>
        </section>

        {/* Skills Matrix Section */}
        <section className="py-20 px-6 lg:px-8 bg-muted/30">
          <div className="max-w-7xl mx-auto">
            {/* Section Header */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-heading font-bold text-foreground mb-4">
                Habilidades por Categoria
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Explore minhas competências técnicas organizadas por área de especialização. 
                Clique nas categorias para ver detalhes de cada tecnologia.
              </p>
            </motion.div>

            {/* Filters and Controls */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex flex-col lg:flex-row items-center justify-between gap-6 mb-8"
            >
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Icon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Buscar habilidade..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e?.target?.value)}
                  className="w-full pl-10 pr-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
                />
              </div>

              {/* Level Filter */}
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Filtrar por nível:</span>
                <select
                  value={filterLevel}
                  onChange={(e) => setFilterLevel(e?.target?.value)}
                  className="px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
                >
                  <option value="all">Todos</option>
                  <option value="expert">Especialista (90%+)</option>
                  <option value="advanced">Avançado (75-89%)</option>
                  <option value="intermediate">Intermediário (60-74%)</option>
                  <option value="beginner">Básico (&lt;60%)</option>
                </select>
              </div>

              {/* Expand/Collapse Controls */}
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={expandAllCategories}
                  iconName="ChevronDown"
                  iconPosition="left"
                >
                  Expandir Todas
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={collapseAllCategories}
                  iconName="ChevronUp"
                  iconPosition="left"
                >
                  Recolher Todas
                </Button>
              </div>
            </motion.div>

            {/* Skills Categories */}
            <div className="space-y-6">
              {filteredSkillsData?.map((category, index) => (
                <SkillCategory
                  key={category?.name}
                  category={category}
                  isExpanded={expandedCategories?.[category?.name]}
                  onToggle={() => toggleCategory(category?.name)}
                  index={index}
                />
              ))}
            </div>

            {/* No Results */}
            {filteredSkillsData?.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12"
              >
                <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  Nenhuma habilidade encontrada
                </h3>
                <p className="text-muted-foreground">
                  Tente ajustar os filtros ou termo de busca.
                </p>
              </motion.div>
            )}
          </div>
        </section>

        {/* Tech Philosophy Section */}
        <section className="py-20 px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <TechPhilosophy />
          </div>
        </section>

        {/* Learning Timeline Section */}
        <section className="py-20 px-6 lg:px-8 bg-muted/30">
          <div className="max-w-7xl mx-auto">
            <LearningTimeline />
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center bg-gradient-to-r from-brand-primary to-brand-secondary rounded-2xl p-12 text-white"
            >
              <Icon name="Rocket" size={48} className="mx-auto mb-6 text-accent" />
              <h2 className="text-3xl font-heading font-bold mb-4">
                Vamos Construir Algo Incrível Juntos?
              </h2>
              <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
                Minhas habilidades estão à disposição para transformar suas ideias em realidade. 
                Entre em contato e vamos discutir seu próximo projeto.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  variant="default"
                  size="lg"
                  onClick={() => window.location.href = '/contact-bridge-professional-connection-hub'}
                  iconName="MessageCircle"
                  iconPosition="left"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Iniciar Conversa
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => window.location.href = '/projects-showcase-interactive-portfolio-gallery'}
                  iconName="FolderOpen"
                  iconPosition="left"
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  Ver Projetos
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default SkillsMatrixPage;