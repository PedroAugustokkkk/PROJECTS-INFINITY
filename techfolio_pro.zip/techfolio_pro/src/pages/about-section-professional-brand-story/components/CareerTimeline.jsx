import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const CareerTimeline = () => {
  const [activeItem, setActiveItem] = useState(0);

  const timelineData = [
    {
      year: '2025',
      title: 'Senior Full-Stack Developer',
      company: 'TechCorp Brasil',
      type: 'Atual',
      description: 'Liderando o desenvolvimento de aplicações React complexas e arquiteturas de microserviços. Mentoria de desenvolvedores júnior e implementação de melhores práticas de desenvolvimento.',
      technologies: ['React 18', 'Node.js', 'TypeScript', 'AWS', 'Docker'],
      achievements: [
        'Reduziu tempo de carregamento em 40%',
        'Implementou CI/CD completo',
        'Liderou equipe de 5 desenvolvedores'
      ]
    },
    {
      year: '2023',
      title: 'Full-Stack Developer',
      company: 'StartupTech',
      type: 'Experiência',
      description: 'Desenvolvimento de plataforma SaaS do zero, desde a concepção até o deploy em produção. Responsável por toda a stack tecnológica e decisões arquiteturais.',
      technologies: ['React', 'Express.js', 'MongoDB', 'Redis', 'Stripe'],
      achievements: [
        'Desenvolveu MVP em 3 meses',
        'Integrou 5+ APIs externas',
        'Alcançou 99.9% de uptime'
      ]
    },
    {
      year: '2021',
      title: 'Frontend Developer',
      company: 'WebSolutions',
      type: 'Crescimento',
      description: 'Especialização em desenvolvimento frontend com foco em performance e experiência do usuário. Trabalho com equipes de design para implementar interfaces pixel-perfect.',
      technologies: ['React', 'Vue.js', 'SASS', 'Webpack', 'Jest'],
      achievements: [
        'Melhorou Core Web Vitals em 60%',
        'Implementou design system',
        'Treinou 3 estagiários'
      ]
    },
    {
      year: '2020',
      title: 'Desenvolvedor Júnior',
      company: 'CodeStart',
      type: 'Início',
      description: 'Primeiros passos profissionais no desenvolvimento web. Aprendizado intensivo de tecnologias modernas e metodologias ágeis em ambiente colaborativo.',
      technologies: ['HTML5', 'CSS3', 'JavaScript', 'PHP', 'MySQL'],
      achievements: [
        'Completou 15+ projetos',
        'Certificação em Scrum',
        'Contribuiu para projetos open source'
      ]
    }
  ];

  const getTypeColor = (type) => {
    switch (type) {
      case 'Atual': return 'bg-accent text-accent-foreground';
      case 'Experiência': return 'bg-brand-primary text-white';
      case 'Crescimento': return 'bg-brand-secondary text-white';
      case 'Início': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center space-x-2 bg-brand-primary/10 text-brand-primary px-4 py-2 rounded-full text-sm font-medium">
          <Icon name="Clock" size={16} />
          <span>Jornada Profissional</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">
          Evolução na Carreira
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Uma trajetória de crescimento constante, sempre buscando novos desafios e oportunidades de aprendizado
        </p>
      </div>
      {/* Timeline */}
      <div className="relative">
        {/* Timeline Line */}
        <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-border transform md:-translate-x-0.5"></div>

        {/* Timeline Items */}
        <div className="space-y-12">
          {timelineData?.map((item, index) => (
            <div
              key={index}
              className={`relative flex flex-col md:flex-row items-start md:items-center ${
                index % 2 === 0 ? 'md:flex-row-reverse' : ''
              }`}
              onMouseEnter={() => setActiveItem(index)}
            >
              {/* Timeline Dot */}
              <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-brand-primary rounded-full border-4 border-background shadow-brand transform md:-translate-x-1/2 z-10">
                {activeItem === index && (
                  <div className="absolute inset-0 bg-accent rounded-full animate-ping"></div>
                )}
              </div>

              {/* Content Card */}
              <div className={`ml-12 md:ml-0 md:w-5/12 ${index % 2 === 0 ? 'md:mr-auto md:pr-8' : 'md:ml-auto md:pl-8'}`}>
                <div className={`bg-background border border-border rounded-xl p-6 shadow-soft hover:shadow-brand transition-all duration-300 hover-lift ${
                  activeItem === index ? 'ring-2 ring-accent/20' : ''
                }`}>
                  {/* Year Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-brand-primary">{item?.year}</span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getTypeColor(item?.type)}`}>
                      {item?.type}
                    </span>
                  </div>

                  {/* Job Info */}
                  <div className="space-y-3 mb-4">
                    <h3 className="text-xl font-heading font-bold text-foreground">
                      {item?.title}
                    </h3>
                    <p className="text-brand-primary font-medium flex items-center">
                      <Icon name="Building" size={16} className="mr-2" />
                      {item?.company}
                    </p>
                    <p className="text-muted-foreground leading-relaxed">
                      {item?.description}
                    </p>
                  </div>

                  {/* Technologies */}
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-foreground mb-2 flex items-center">
                      <Icon name="Code" size={14} className="mr-2" />
                      Tecnologias
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {item?.technologies?.map((tech, techIndex) => (
                        <span
                          key={techIndex}
                          className="px-2 py-1 bg-brand-surface text-brand-primary text-xs rounded-md border border-brand-primary/20"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Achievements */}
                  <div>
                    <h4 className="text-sm font-medium text-foreground mb-2 flex items-center">
                      <Icon name="Trophy" size={14} className="mr-2" />
                      Principais Conquistas
                    </h4>
                    <ul className="space-y-1">
                      {item?.achievements?.map((achievement, achIndex) => (
                        <li key={achIndex} className="text-sm text-muted-foreground flex items-start">
                          <Icon name="CheckCircle" size={12} className="mr-2 mt-0.5 text-accent flex-shrink-0" />
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Stats Section */}
      <div className="bg-brand-surface rounded-2xl p-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="space-y-2">
            <div className="text-3xl font-bold text-brand-primary">5+</div>
            <div className="text-sm text-muted-foreground">Anos de Experiência</div>
          </div>
          <div className="space-y-2">
            <div className="text-3xl font-bold text-brand-primary">50+</div>
            <div className="text-sm text-muted-foreground">Projetos Concluídos</div>
          </div>
          <div className="space-y-2">
            <div className="text-3xl font-bold text-brand-primary">15+</div>
            <div className="text-sm text-muted-foreground">Tecnologias</div>
          </div>
          <div className="space-y-2">
            <div className="text-3xl font-bold text-brand-primary">100%</div>
            <div className="text-sm text-muted-foreground">Satisfação</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareerTimeline;