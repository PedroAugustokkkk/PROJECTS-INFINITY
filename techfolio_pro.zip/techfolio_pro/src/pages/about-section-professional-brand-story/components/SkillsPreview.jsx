import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SkillsPreview = () => {
  const [activeCategory, setActiveCategory] = useState('frontend');

  const skillCategories = {
    frontend: {
      title: 'Frontend Development',
      icon: 'Monitor',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      skills: [
        { name: 'React', level: 95, icon: 'Component' },
        { name: 'TypeScript', level: 90, icon: 'Code2' },
        { name: 'Next.js', level: 88, icon: 'Zap' },
        { name: 'Tailwind CSS', level: 92, icon: 'Palette' }
      ]
    },
    backend: {
      title: 'Backend Development',
      icon: 'Server',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      skills: [
        { name: 'Node.js', level: 90, icon: 'Cpu' },
        { name: 'Express.js', level: 85, icon: 'Layers' },
        { name: 'MongoDB', level: 82, icon: 'Database' },
        { name: 'PostgreSQL', level: 78, icon: 'HardDrive' }
      ]
    },
    tools: {
      title: 'Ferramentas & DevOps',
      icon: 'Settings',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      skills: [
        { name: 'Git', level: 93, icon: 'GitBranch' },
        { name: 'Docker', level: 80, icon: 'Package' },
        { name: 'AWS', level: 75, icon: 'Cloud' },
        { name: 'Figma', level: 85, icon: 'Figma' }
      ]
    }
  };

  const categories = Object.keys(skillCategories);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center space-x-2 bg-accent/10 text-accent-foreground px-4 py-2 rounded-full text-sm font-medium">
          <Icon name="Zap" size={16} />
          <span>Habilidades Técnicas</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">
          Stack Tecnológico
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Domínio em tecnologias modernas para criar soluções completas e escaláveis
        </p>
      </div>
      {/* Category Tabs */}
      <div className="flex flex-wrap justify-center gap-2">
        {categories?.map((category) => {
          const categoryData = skillCategories?.[category];
          return (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover-lift ${
                activeCategory === category
                  ? 'bg-brand-primary text-white shadow-brand'
                  : 'bg-brand-surface text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={categoryData?.icon} size={16} />
              <span>{categoryData?.title}</span>
            </button>
          );
        })}
      </div>
      {/* Skills Display */}
      <div className="bg-background border border-border rounded-2xl p-8 shadow-soft">
        <div className="space-y-6">
          {/* Category Header */}
          <div className="flex items-center space-x-3">
            <div className={`w-12 h-12 ${skillCategories?.[activeCategory]?.bgColor} rounded-lg flex items-center justify-center`}>
              <Icon 
                name={skillCategories?.[activeCategory]?.icon} 
                size={24} 
                className={skillCategories?.[activeCategory]?.color}
              />
            </div>
            <div>
              <h3 className="text-xl font-heading font-bold text-foreground">
                {skillCategories?.[activeCategory]?.title}
              </h3>
              <p className="text-sm text-muted-foreground">
                Tecnologias que domino nesta área
              </p>
            </div>
          </div>

          {/* Skills Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {skillCategories?.[activeCategory]?.skills?.map((skill, index) => (
              <div key={index} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Icon name={skill?.icon} size={16} className="text-brand-primary" />
                    <span className="font-medium text-foreground">{skill?.name}</span>
                  </div>
                  <span className="text-sm font-bold text-brand-primary">{skill?.level}%</span>
                </div>
                
                {/* Progress Bar */}
                <div className="relative">
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-brand-primary to-accent h-2 rounded-full transition-all duration-1000 ease-out"
                      style={{ width: `${skill?.level}%` }}
                    ></div>
                  </div>
                  {/* Skill Level Indicator */}
                  <div 
                    className="absolute top-0 w-3 h-3 bg-accent rounded-full border-2 border-background shadow-soft transform -translate-y-0.5 transition-all duration-1000 ease-out"
                    style={{ left: `calc(${skill?.level}% - 6px)` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* CTA to Full Skills Page */}
      <div className="text-center bg-brand-surface rounded-2xl p-8">
        <div className="space-y-4">
          <Icon name="Target" size={48} className="text-brand-primary mx-auto" />
          <h3 className="text-2xl font-heading font-bold text-foreground">
            Quer Ver Todas as Minhas Habilidades?
          </h3>
          <p className="text-muted-foreground max-w-md mx-auto">
            Explore minha matriz completa de habilidades técnicas, certificações e projetos práticos
          </p>
          <Button
            variant="default"
            onClick={() => window.location.href = '/skills-matrix-dynamic-technical-capabilities'}
            iconName="ArrowRight"
            iconPosition="right"
            className="bg-brand-primary hover:bg-brand-secondary"
          >
            Ver Habilidades Completas
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SkillsPreview;