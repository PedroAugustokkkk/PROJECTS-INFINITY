import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PersonalStory = () => {
  const highlights = [
    {
      icon: 'Code',
      title: 'Paixão por Código',
      description: 'Transformando ideias em soluções digitais há mais de 5 anos'
    },
    {
      icon: 'Lightbulb',
      title: 'Inovação Constante',
      description: 'Sempre explorando novas tecnologias e metodologias'
    },
    {
      icon: 'Users',
      title: 'Colaboração',
      description: 'Experiência em equipes ágeis e projetos multidisciplinares'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="space-y-4">
        <div className="inline-flex items-center space-x-2 bg-accent/10 text-accent-foreground px-4 py-2 rounded-full text-sm font-medium">
          <Icon name="User" size={16} />
          <span>Sobre Mim</span>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-foreground leading-tight">
          Desenvolvedor Full-Stack
          <span className="block text-brand-primary">Apaixonado por Tecnologia</span>
        </h1>
        
        <p className="text-xl text-muted-foreground leading-relaxed">
          Criando experiências digitais excepcionais que conectam pessoas e transformam negócios
        </p>
      </div>
      {/* Story Content */}
      <div className="space-y-6 text-foreground leading-relaxed">
        <p className="text-lg">
          Olá! Sou um desenvolvedor full-stack brasileiro com mais de <strong className="text-brand-primary">5 anos de experiência</strong> 
          criando soluções web modernas e escaláveis. Minha jornada na tecnologia começou com curiosidade sobre como os sites funcionam 
          e evoluiu para uma paixão profunda por arquitetar sistemas complexos que resolvem problemas reais.
        </p>

        <p>
          Especializo-me em <strong className="text-brand-primary">React, Node.js e tecnologias modernas</strong>, sempre focando em 
          código limpo, performance otimizada e experiência do usuário excepcional. Acredito que a melhor tecnologia é aquela que 
          as pessoas nem percebem que está lá - simplesmente funciona perfeitamente.
        </p>

        <p>
          Ao longo da minha carreira, tive o privilégio de trabalhar com startups inovadoras e empresas estabelecidas, 
          sempre buscando o equilíbrio perfeito entre <strong className="text-brand-primary">inovação técnica e valor de negócio</strong>. 
          Cada projeto é uma oportunidade de aprender algo novo e criar algo significativo.
        </p>
      </div>
      {/* Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {highlights?.map((highlight, index) => (
          <div 
            key={index}
            className="bg-brand-surface border border-border rounded-xl p-6 hover:shadow-brand transition-all duration-300 hover-lift"
          >
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-12 h-12 bg-accent rounded-lg flex items-center justify-center">
                <Icon name={highlight?.icon} size={24} className="text-accent-foreground" />
              </div>
              <div className="space-y-2">
                <h3 className="font-heading font-semibold text-foreground">
                  {highlight?.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {highlight?.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* CTA Section */}
      <div className="bg-gradient-brand rounded-2xl p-8 text-center">
        <h3 className="text-2xl font-heading font-bold text-white mb-4">
          Vamos Construir Algo Incrível Juntos?
        </h3>
        <p className="text-white/90 mb-6 max-w-md mx-auto">
          Estou sempre aberto a novos desafios e oportunidades de colaboração. 
          Vamos conversar sobre seu próximo projeto!
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            variant="secondary"
            onClick={() => window.location.href = '/contact-bridge-professional-connection-hub'}
            iconName="MessageCircle"
            iconPosition="left"
            className="bg-white text-brand-primary hover:bg-white/90"
          >
            Entre em Contato
          </Button>
          <Button
            variant="outline"
            onClick={() => window.location.href = '/projects-showcase-interactive-portfolio-gallery'}
            iconName="FolderOpen"
            iconPosition="left"
            className="border-white text-white hover:bg-white/10"
          >
            Ver Projetos
          </Button>
        </div>
      </div>
    </div>
  );
};

export default PersonalStory;