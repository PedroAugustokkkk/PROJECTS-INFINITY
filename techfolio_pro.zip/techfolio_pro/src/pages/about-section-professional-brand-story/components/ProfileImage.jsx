import React from 'react';
import Image from '../../../components/AppImage';

const ProfileImage = () => {
  return (
    <div className="relative">
      {/* Main Profile Image Container */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-brand p-1 shadow-brand hover-scale">
        <div className="overflow-hidden rounded-xl bg-background">
          <Image
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=600&fit=crop&crop=face"
            alt="Desenvolvedor Full-Stack - Foto Profissional"
            className="w-full h-[400px] md:h-[500px] object-cover transition-transform duration-500 hover:scale-105"
          />
        </div>
      </div>

      {/* Floating Status Badge */}
      <div className="absolute -top-2 -right-2 bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-medium shadow-brand animate-pulse">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span>Disponível</span>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-accent/20 rounded-full blur-xl"></div>
      <div className="absolute -top-4 -right-4 w-16 h-16 bg-brand-primary/20 rounded-full blur-lg"></div>

      {/* Experience Badge */}
      <div className="absolute bottom-4 left-4 bg-background/95 backdrop-blur-sm border border-border rounded-lg px-3 py-2 shadow-soft">
        <div className="text-center">
          <div className="text-2xl font-bold text-brand-primary">5+</div>
          <div className="text-xs text-muted-foreground">Anos</div>
        </div>
      </div>
    </div>
  );
};

export default ProfileImage;