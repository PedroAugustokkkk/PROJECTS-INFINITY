import React, { useEffect } from 'react';
import Header from '../../components/ui/Header';
import ProfileImage from './components/ProfileImage';
import PersonalStory from './components/PersonalStory';
import CareerTimeline from './components/CareerTimeline';
import SkillsPreview from './components/SkillsPreview';

const AboutSectionProfessionalBrandStory = () => {
  useEffect(() => {
    // Scroll to top on component mount
    window.scrollTo(0, 0);
    
    // Set page title
    document.title = 'Sobre Mim - TechFolio Pro | Desenvolvedor Full-Stack';
    
    // Add meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription?.setAttribute('content', 'Conheça minha jornada como desenvolvedor full-stack brasileiro. Mais de 5 anos criando soluções web modernas com React, Node.js e tecnologias de ponta.');
    }
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      {/* Main Content */}
      <main className="pt-16">
        {/* Hero Section */}
        <section className="py-16 md:py-24 bg-gradient-to-br from-brand-surface via-background to-accent/5">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              {/* Personal Story */}
              <div className="order-2 lg:order-1">
                <PersonalStory />
              </div>
              
              {/* Profile Image */}
              <div className="order-1 lg:order-2">
                <ProfileImage />
              </div>
            </div>
          </div>
        </section>

        {/* Career Timeline Section */}
        <section className="py-16 md:py-24 bg-background">
          <div className="max-w-6xl mx-auto px-6 lg:px-8">
            <CareerTimeline />
          </div>
        </section>

        {/* Skills Preview Section */}
        <section className="py-16 md:py-24 bg-brand-surface">
          <div className="max-w-6xl mx-auto px-6 lg:px-8">
            <SkillsPreview />
          </div>
        </section>

        {/* Values & Philosophy Section */}
        <section className="py-16 md:py-24 bg-background">
          <div className="max-w-6xl mx-auto px-6 lg:px-8">
            <div className="text-center space-y-12">
              {/* Header */}
              <div className="space-y-4">
                <div className="inline-flex items-center space-x-2 bg-brand-primary/10 text-brand-primary px-4 py-2 rounded-full text-sm font-medium">
                  <span>💡</span>
                  <span>Filosofia de Trabalho</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground">
                  Valores que Guiam Meu Trabalho
                </h2>
              </div>

              {/* Values Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-background border border-border rounded-xl p-8 text-center hover:shadow-brand transition-all duration-300 hover-lift">
                  <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-2xl">🎯</span>
                  </div>
                  <h3 className="text-xl font-heading font-bold text-foreground mb-4">
                    Foco na Qualidade
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Cada linha de código é escrita pensando em manutenibilidade, performance e escalabilidade. 
                    Qualidade não é negociável.
                  </p>
                </div>

                <div className="bg-background border border-border rounded-xl p-8 text-center hover:shadow-brand transition-all duration-300 hover-lift">
                  <div className="w-16 h-16 bg-brand-primary rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-2xl text-white">🚀</span>
                  </div>
                  <h3 className="text-xl font-heading font-bold text-foreground mb-4">
                    Inovação Constante
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Sempre explorando novas tecnologias e metodologias para entregar soluções 
                    mais eficientes e modernas.
                  </p>
                </div>

                <div className="bg-background border border-border rounded-xl p-8 text-center hover:shadow-brand transition-all duration-300 hover-lift">
                  <div className="w-16 h-16 bg-brand-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                    <span className="text-2xl text-white">🤝</span>
                  </div>
                  <h3 className="text-xl font-heading font-bold text-foreground mb-4">
                    Colaboração Efetiva
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Acredito que os melhores resultados vêm do trabalho em equipe, comunicação clara 
                    e compartilhamento de conhecimento.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="py-16 md:py-24 bg-gradient-brand">
          <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
            <div className="space-y-8">
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-white">
                Pronto para Transformar Suas Ideias em Realidade?
              </h2>
              <p className="text-xl text-white/90 max-w-2xl mx-auto leading-relaxed">
                Seja para um projeto inovador, uma consultoria técnica ou uma oportunidade de carreira, 
                estou sempre aberto a novas possibilidades.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => window.location.href = '/projects-showcase-interactive-portfolio-gallery'}
                  className="bg-white text-brand-primary px-8 py-4 rounded-lg font-medium hover:bg-white/90 transition-colors hover-lift flex items-center justify-center space-x-2"
                >
                  <span>Ver Meus Projetos</span>
                  <span>→</span>
                </button>
                <button
                  onClick={() => window.location.href = '/contact-bridge-professional-connection-hub'}
                  className="border-2 border-white text-white px-8 py-4 rounded-lg font-medium hover:bg-white/10 transition-colors hover-lift flex items-center justify-center space-x-2"
                >
                  <span>Vamos Conversar</span>
                  <span>💬</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>
      {/* Footer */}
      <footer className="bg-foreground text-white py-12">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                  <span className="text-accent-foreground font-bold text-lg font-mono">TP</span>
                </div>
                <span className="text-xl font-heading font-bold">TechFolio Pro</span>
              </div>
              <p className="text-white/70 text-sm">
                Desenvolvedor Full-Stack apaixonado por criar soluções digitais excepcionais.
              </p>
            </div>

            {/* Navigation */}
            <div className="space-y-4">
              <h4 className="font-heading font-semibold">Navegação</h4>
              <div className="space-y-2 text-sm">
                <button 
                  onClick={() => window.location.href = '/homepage-interactive-it-portfolio'}
                  className="block text-white/70 hover:text-white transition-colors"
                >
                  Início
                </button>
                <button 
                  onClick={() => window.location.href = '/about-section-professional-brand-story'}
                  className="block text-white/70 hover:text-white transition-colors"
                >
                  Sobre
                </button>
                <button 
                  onClick={() => window.location.href = '/projects-showcase-interactive-portfolio-gallery'}
                  className="block text-white/70 hover:text-white transition-colors"
                >
                  Projetos
                </button>
                <button 
                  onClick={() => window.location.href = '/skills-matrix-dynamic-technical-capabilities'}
                  className="block text-white/70 hover:text-white transition-colors"
                >
                  Habilidades
                </button>
              </div>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h4 className="font-heading font-semibold">Contato</h4>
              <div className="space-y-2 text-sm text-white/70">
                <p>contato@techfolio.dev</p>
                <p>+55 (11) 99999-9999</p>
                <p>São Paulo, Brasil</p>
              </div>
            </div>

            {/* Social */}
            <div className="space-y-4">
              <h4 className="font-heading font-semibold">Redes Sociais</h4>
              <div className="flex space-x-4">
                <button className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                  <span className="text-sm">in</span>
                </button>
                <button className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                  <span className="text-sm">gh</span>
                </button>
                <button className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                  <span className="text-sm">tw</span>
                </button>
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="border-t border-white/10 mt-8 pt-8 text-center text-sm text-white/50">
            <p>&copy; {new Date()?.getFullYear()} TechFolio Pro. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default AboutSectionProfessionalBrandStory;