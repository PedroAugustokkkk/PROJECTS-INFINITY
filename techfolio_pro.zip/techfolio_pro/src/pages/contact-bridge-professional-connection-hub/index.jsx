import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/ui/Header';
import ContactHero from './components/ContactHero';
import ContactForm from './components/ContactForm';
import ContactInfo from './components/ContactInfo';
import SocialProof from './components/SocialProof';
import Icon from '../../components/AppIcon';

const ContactBridgePage = () => {
  useEffect(() => {
    document.title = 'Contato - TechFolio Pro | Desenvolvedor Full-Stack';
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription?.setAttribute('content', 
        'Entre em contato com TechFolio Pro para desenvolvimento web, consultoria técnica e soluções digitais inovadoras. Resposta garantida em 24 horas.'
      );
    }
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.6,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 }
    }
  };

  const scrollToForm = () => {
    document.getElementById('contact-form')?.scrollIntoView({ 
      behavior: 'smooth',
      block: 'start'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <motion.section
          className="px-6 lg:px-8 py-12 lg:py-20"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <div className="max-w-7xl mx-auto">
            <motion.div variants={itemVariants}>
              <ContactHero />
            </motion.div>
          </div>
        </motion.section>

        {/* Main Content */}
        <motion.section
          className="px-6 lg:px-8 py-12 lg:py-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              {/* Contact Form - Main Column */}
              <motion.div 
                className="lg:col-span-2"
                variants={itemVariants}
                id="contact-form"
              >
                <ContactForm />
              </motion.div>

              {/* Contact Info - Sidebar */}
              <motion.div 
                className="lg:col-span-1"
                variants={itemVariants}
              >
                <ContactInfo />
              </motion.div>
            </div>
          </div>
        </motion.section>

        {/* Social Proof Section */}
        <motion.section
          className="px-6 lg:px-8 py-12 lg:py-20 bg-muted/30"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <div className="max-w-7xl mx-auto">
            <motion.div
              className="text-center mb-12"
              variants={itemVariants}
            >
              <h2 className="text-3xl lg:text-4xl font-heading font-bold text-foreground mb-4">
                Confiança Construída com Resultados
              </h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                Mais de 50 projetos entregues com excelência, clientes satisfeitos e uma reputação sólida 
                no mercado brasileiro de tecnologia.
              </p>
            </motion.div>

            <motion.div variants={itemVariants}>
              <SocialProof />
            </motion.div>
          </div>
        </motion.section>

        {/* CTA Section */}
        <motion.section
          className="px-6 lg:px-8 py-12 lg:py-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={containerVariants}
        >
          <div className="max-w-4xl mx-auto text-center">
            <motion.div variants={itemVariants}>
              <div className="bg-gradient-brand rounded-3xl p-8 lg:p-12 text-white relative overflow-hidden">
                {/* Background Pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute top-0 left-0 w-full h-full">
                    <div className="absolute top-10 left-10 w-20 h-20 border border-white/20 rounded-full animate-pulse"></div>
                    <div className="absolute bottom-10 right-10 w-16 h-16 border border-white/20 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
                  </div>
                </div>

                <div className="relative z-10">
                  <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Icon name="Rocket" size={32} className="text-accent" />
                  </div>
                  
                  <h2 className="text-3xl lg:text-4xl font-heading font-bold mb-4">
                    Pronto para Começar?
                  </h2>
                  
                  <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
                    Não importa se é um projeto pequeno ou uma solução enterprise complexa. 
                    Vamos conversar sobre como posso ajudar você a alcançar seus objetivos.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <button
                      onClick={scrollToForm}
                      className="bg-white text-brand-primary px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-colors inline-flex items-center justify-center space-x-2 hover-lift"
                    >
                      <Icon name="MessageCircle" size={20} />
                      <span>Iniciar Conversa</span>
                    </button>
                    
                    <button
                      onClick={() => window.open('https://wa.me/5511999998888', '_blank')}
                      className="border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white/10 transition-colors inline-flex items-center justify-center space-x-2 hover-lift"
                    >
                      <Icon name="Phone" size={20} />
                      <span>WhatsApp</span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.section>
      </main>
      {/* Footer */}
      <footer className="bg-brand-primary text-white py-12">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                  <span className="text-brand-primary font-bold text-lg font-mono">TP</span>
                </div>
                <div>
                  <h3 className="text-xl font-heading font-bold">TechFolio Pro</h3>
                  <p className="text-sm opacity-80">Full-Stack Developer</p>
                </div>
              </div>
              <p className="text-sm opacity-80">
                Transformando ideias em soluções digitais inovadoras com tecnologia de ponta.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contato Rápido</h4>
              <div className="space-y-2 text-sm opacity-80">
                <p>📧 contato@techfolio.dev</p>
                <p>📱 +55 (11) 99999-8888</p>
                <p>📍 São Paulo, Brasil</p>
                <p>🕒 Seg-Sex: 9h às 18h</p>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Redes Sociais</h4>
              <div className="flex space-x-4">
                <button
                  onClick={() => window.open('https://linkedin.com/in/techfolio-pro', '_blank')}
                  className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Icon name="Linkedin" size={20} />
                </button>
                <button
                  onClick={() => window.open('https://github.com/techfolio-pro', '_blank')}
                  className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Icon name="Github" size={20} />
                </button>
                <button
                  onClick={() => window.open('https://wa.me/5511999998888', '_blank')}
                  className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Icon name="MessageCircle" size={20} />
                </button>
              </div>
            </div>
          </div>

          <div className="border-t border-white/20 mt-8 pt-8 text-center">
            <p className="text-sm opacity-80">
              © {new Date()?.getFullYear()} TechFolio Pro. Todos os direitos reservados. 
              Desenvolvido com ❤️ em São Paulo.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ContactBridgePage;