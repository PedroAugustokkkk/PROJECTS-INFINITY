import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const ContactInfo = () => {
  const contactMethods = [
    {
      icon: 'Mail',
      label: 'Email Profissional',
      value: 'contato@techfolio.dev',
      description: 'Resposta em até 24 horas',
      action: () => window.open('mailto:contato@techfolio.dev', '_blank'),
      primary: true
    },
    {
      icon: 'Linkedin',
      label: 'LinkedIn',
      value: '/in/techfolio-pro',
      description: 'Rede profissional e conexões',
      action: () => window.open('https://linkedin.com/in/techfolio-pro', '_blank'),
      primary: false
    },
    {
      icon: 'Github',
      label: 'GitHub',
      value: '@techfolio-pro',
      description: 'Código e projetos open source',
      action: () => window.open('https://github.com/techfolio-pro', '_blank'),
      primary: false
    },
    {
      icon: 'Phone',
      label: 'WhatsApp Business',
      value: '+55 (11) 99999-8888',
      description: 'Apenas projetos urgentes',
      action: () => window.open('https://wa.me/5511999998888', '_blank'),
      primary: false
    }
  ];

  const downloadCV = () => {
    // Simulate CV download
    const link = document.createElement('a');
    link.href = '/assets/cv/TechFolio-Pro-CV-2024.pdf';
    link.download = 'TechFolio-Pro-CV-2024.pdf';
    link?.click();
  };

  const scheduleCall = () => {
    window.open('https://calendly.com/techfolio-pro/30min', '_blank');
  };

  return (
    <div className="space-y-8">
      {/* Availability Status */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-heading font-bold text-foreground">
            Status de Disponibilidade
          </h3>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-success">Disponível</span>
          </div>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Novos Projetos:</span>
            <span className="text-success font-medium">Aceitando</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Consultorias:</span>
            <span className="text-success font-medium">Disponível</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Tempo de Resposta:</span>
            <span className="text-foreground font-medium">24 horas</span>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Atualmente com capacidade para 2 novos projetos. Especializado em React, Node.js e arquiteturas cloud.
          </p>
        </div>
      </div>
      {/* Contact Methods */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <h3 className="text-lg font-heading font-bold text-foreground mb-6">
          Canais de Contato
        </h3>
        
        <div className="space-y-4">
          {contactMethods?.map((method, index) => (
            <button
              key={index}
              onClick={method?.action}
              className={`w-full p-4 rounded-xl border transition-all duration-200 hover-lift text-left ${
                method?.primary
                  ? 'border-accent bg-accent/5 hover:bg-accent/10' :'border-border hover:border-accent/50 hover:bg-muted/50'
              }`}
            >
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  method?.primary
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-muted text-muted-foreground'
                }`}>
                  <Icon name={method?.icon} size={20} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-foreground">{method?.label}</h4>
                    <Icon name="ExternalLink" size={16} className="text-muted-foreground" />
                  </div>
                  <p className="text-sm text-accent font-mono">{method?.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{method?.description}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
      {/* Quick Actions */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <h3 className="text-lg font-heading font-bold text-foreground mb-6">
          Ações Rápidas
        </h3>
        
        <div className="space-y-4">
          <Button
            variant="default"
            fullWidth
            onClick={downloadCV}
            iconName="Download"
            iconPosition="left"
            className="bg-brand-primary hover:bg-brand-secondary"
          >
            Baixar Currículo (PDF)
          </Button>
          
          <Button
            variant="outline"
            fullWidth
            onClick={scheduleCall}
            iconName="Calendar"
            iconPosition="left"
          >
            Agendar Reunião (30min)
          </Button>
          
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="ghost"
              onClick={() => window.open('https://github.com/techfolio-pro', '_blank')}
              iconName="Github"
              iconPosition="left"
              size="sm"
            >
              GitHub
            </Button>
            <Button
              variant="ghost"
              onClick={() => window.open('https://linkedin.com/in/techfolio-pro', '_blank')}
              iconName="Linkedin"
              iconPosition="left"
              size="sm"
            >
              LinkedIn
            </Button>
          </div>
        </div>
      </div>
      {/* Location & Timezone */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <h3 className="text-lg font-heading font-bold text-foreground mb-4">
          Localização & Fuso Horário
        </h3>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <Icon name="MapPin" size={20} className="text-accent" />
            <div>
              <p className="font-medium text-foreground">São Paulo, Brasil</p>
              <p className="text-sm text-muted-foreground">Disponível para trabalho remoto</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Icon name="Clock" size={20} className="text-accent" />
            <div>
              <p className="font-medium text-foreground">GMT-3 (Brasília)</p>
              <p className="text-sm text-muted-foreground">
                Horário comercial: 9h às 18h
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Icon name="Globe" size={20} className="text-accent" />
            <div>
              <p className="font-medium text-foreground">Idiomas</p>
              <p className="text-sm text-muted-foreground">
                Português (nativo), Inglês (fluente)
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactInfo;