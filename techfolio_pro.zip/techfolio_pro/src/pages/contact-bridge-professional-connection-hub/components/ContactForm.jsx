import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const ContactForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch
  } = useForm();

  const projectTypeOptions = [
    { value: 'web-development', label: 'Desenvolvimento Web' },
    { value: 'mobile-app', label: 'Aplicativo Mobile' },
    { value: 'consulting', label: 'Consultoria Técnica' },
    { value: 'collaboration', label: 'Colaboração em Projeto' },
    { value: 'other', label: 'Outro' }
  ];

  const timelineOptions = [
    { value: 'urgent', label: 'Urgente (1-2 semanas)' },
    { value: 'short', label: 'Curto prazo (1-2 meses)' },
    { value: 'medium', label: 'Médio prazo (3-6 meses)' },
    { value: 'long', label: 'Longo prazo (6+ meses)' },
    { value: 'flexible', label: 'Flexível' }
  ];

  const budgetOptions = [
    { value: 'under-5k', label: 'Até R$ 5.000' },
    { value: '5k-15k', label: 'R$ 5.000 - R$ 15.000' },
    { value: '15k-30k', label: 'R$ 15.000 - R$ 30.000' },
    { value: '30k-50k', label: 'R$ 30.000 - R$ 50.000' },
    { value: 'above-50k', label: 'Acima de R$ 50.000' },
    { value: 'discuss', label: 'Prefiro discutir' }
  ];

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    console.log('Form submitted:', data);
    setSubmitSuccess(true);
    setIsSubmitting(false);
    reset();
    
    // Reset success message after 5 seconds
    setTimeout(() => setSubmitSuccess(false), 5000);
  };

  if (submitSuccess) {
    return (
      <div className="bg-card rounded-2xl p-8 shadow-brand border border-border">
        <div className="text-center">
          <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="CheckCircle" size={32} className="text-success" />
          </div>
          <h3 className="text-xl font-heading font-bold text-foreground mb-2">
            Mensagem Enviada com Sucesso!
          </h3>
          <p className="text-muted-foreground mb-6">
            Obrigado pelo seu interesse! Entrarei em contato em até 24 horas.
          </p>
          <Button
            variant="outline"
            onClick={() => setSubmitSuccess(false)}
            iconName="ArrowLeft"
            iconPosition="left"
          >
            Enviar Nova Mensagem
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl p-8 shadow-brand border border-border">
      <div className="mb-6">
        <h3 className="text-2xl font-heading font-bold text-foreground mb-2">
          Vamos Trabalhar Juntos
        </h3>
        <p className="text-muted-foreground">
          Conte-me sobre seu projeto e como posso ajudar a transformar sua ideia em realidade.
        </p>
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Nome Completo"
            type="text"
            placeholder="Seu nome"
            required
            error={errors?.name?.message}
            {...register('name', {
              required: 'Nome é obrigatório',
              minLength: {
                value: 2,
                message: 'Nome deve ter pelo menos 2 caracteres'
              }
            })}
          />

          <Input
            label="Email"
            type="email"
            placeholder="seu@email.com"
            required
            error={errors?.email?.message}
            {...register('email', {
              required: 'Email é obrigatório',
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: 'Email inválido'
              }
            })}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input
            label="Empresa/Organização"
            type="text"
            placeholder="Nome da empresa (opcional)"
            {...register('company')}
          />

          <Input
            label="Telefone"
            type="tel"
            placeholder="(11) 99999-9999"
            {...register('phone')}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Select
            label="Tipo de Projeto"
            placeholder="Selecione o tipo"
            options={projectTypeOptions}
            required
            error={errors?.projectType?.message}
            {...register('projectType', {
              required: 'Tipo de projeto é obrigatório'
            })}
          />

          <Select
            label="Prazo Desejado"
            placeholder="Selecione o prazo"
            options={timelineOptions}
            {...register('timeline')}
          />

          <Select
            label="Orçamento Estimado"
            placeholder="Selecione a faixa"
            options={budgetOptions}
            {...register('budget')}
          />
        </div>

        <div>
          <Input
            label="Assunto"
            type="text"
            placeholder="Resumo do seu projeto"
            required
            error={errors?.subject?.message}
            {...register('subject', {
              required: 'Assunto é obrigatório',
              minLength: {
                value: 5,
                message: 'Assunto deve ter pelo menos 5 caracteres'
              }
            })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Descrição do Projeto *
          </label>
          <textarea
            className="w-full px-4 py-3 border border-border rounded-lg focus:ring-2 focus:ring-accent focus:border-transparent resize-none transition-colors"
            rows={6}
            placeholder="Descreva seu projeto, objetivos, requisitos técnicos e qualquer informação relevante..."
            {...register('message', {
              required: 'Descrição do projeto é obrigatória',
              minLength: {
                value: 20,
                message: 'Descrição deve ter pelo menos 20 caracteres'
              }
            })}
          />
          {errors?.message && (
            <p className="mt-1 text-sm text-error">{errors?.message?.message}</p>
          )}
        </div>

        <div className="space-y-4">
          <div className="border-t border-border pt-4">
            <h4 className="text-sm font-medium text-foreground mb-3">
              Preferências de Comunicação
            </h4>
            <div className="space-y-2">
              <Checkbox
                label="Gostaria de receber atualizações sobre o projeto por email"
                {...register('emailUpdates')}
              />
              <Checkbox
                label="Interessado em agendar uma reunião inicial"
                {...register('scheduleMeeting')}
              />
            </div>
          </div>

          <div className="bg-muted/50 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Icon name="Shield" size={20} className="text-accent mt-0.5" />
              <div className="text-sm text-muted-foreground">
                <p className="font-medium text-foreground mb-1">
                  Proteção de Dados (LGPD)
                </p>
                <p>
                  Seus dados serão utilizados apenas para responder sua solicitação e não serão compartilhados com terceiros. 
                  Você pode solicitar a exclusão dos seus dados a qualquer momento.
                </p>
              </div>
            </div>
          </div>

          <Checkbox
            label="Concordo com o tratamento dos meus dados pessoais conforme descrito acima"
            required
            error={errors?.dataConsent?.message}
            {...register('dataConsent', {
              required: 'É necessário concordar com o tratamento de dados'
            })}
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-4 pt-4">
          <Button
            type="submit"
            variant="default"
            size="lg"
            loading={isSubmitting}
            iconName="Send"
            iconPosition="right"
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            {isSubmitting ? 'Enviando...' : 'Enviar Mensagem'}
          </Button>
          
          <Button
            type="button"
            variant="outline"
            size="lg"
            onClick={() => reset()}
            iconName="RotateCcw"
            iconPosition="left"
          >
            Limpar Formulário
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ContactForm;