import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const SocialProof = () => {
  const testimonials = [
    {
      id: 1,
      name: "Marina Silva",
      role: "CTO",
      company: "TechStart Brasil",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      content: `Trabalhar com o TechFolio Pro foi excepcional. Entregou nossa plataforma e-commerce em React com qualidade impecável e dentro do prazo. Recomendo fortemente!`,
      rating: 5,
      project: "E-commerce Platform"
    },
    {
      id: 2,
      name: "Carlos Mendes",
      role: "Founder",
      company: "InovaTech Solutions",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      content: `Profissional extremamente competente. Desenvolveu nossa API em Node.js com arquitetura robusta e documentação completa. Superou nossas expectativas.`,
      rating: 5,
      project: "API Development"
    },
    {
      id: 3,
      name: "Ana Rodrigues",
      role: "Product Manager",
      company: "Digital Ventures",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      content: `Comunicação clara, código limpo e entrega pontual. O dashboard que desenvolveu transformou nossa operação. Definitivamente voltaremos a trabalhar juntos.`,
      rating: 5,
      project: "Dashboard Development"
    }
  ];

  const achievements = [
    {
      icon: 'Award',
      label: 'Projetos Concluídos',
      value: '50+',
      description: 'Aplicações web e mobile'
    },
    {
      icon: 'Users',
      label: 'Clientes Satisfeitos',
      value: '30+',
      description: 'Startups e empresas'
    },
    {
      icon: 'Star',
      label: 'Avaliação Média',
      value: '4.9/5',
      description: 'Baseado em feedback'
    },
    {
      icon: 'Clock',
      label: 'Tempo de Resposta',
      value: '< 24h',
      description: 'Comunicação rápida'
    }
  ];

  const certifications = [
    {
      name: 'AWS Certified Developer',
      issuer: 'Amazon Web Services',
      year: '2024',
      icon: 'Cloud'
    },
    {
      name: 'React Professional Certificate',
      issuer: 'Meta',
      year: '2023',
      icon: 'Code'
    },
    {
      name: 'Node.js Application Developer',
      issuer: 'OpenJS Foundation',
      year: '2023',
      icon: 'Server'
    }
  ];

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={16}
        className={index < rating ? 'text-accent fill-current' : 'text-muted-foreground'}
      />
    ));
  };

  return (
    <div className="space-y-8">
      {/* Achievements Stats */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <h3 className="text-lg font-heading font-bold text-foreground mb-6">
          Números que Falam por Si
        </h3>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {achievements?.map((achievement, index) => (
            <div key={index} className="text-center p-4 rounded-xl bg-muted/50">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Icon name={achievement?.icon} size={24} className="text-accent" />
              </div>
              <div className="text-2xl font-bold text-foreground mb-1">
                {achievement?.value}
              </div>
              <div className="text-sm font-medium text-foreground mb-1">
                {achievement?.label}
              </div>
              <div className="text-xs text-muted-foreground">
                {achievement?.description}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Client Testimonials */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <h3 className="text-lg font-heading font-bold text-foreground mb-6">
          O que Dizem os Clientes
        </h3>
        
        <div className="space-y-6">
          {testimonials?.map((testimonial) => (
            <div key={testimonial?.id} className="border border-border rounded-xl p-6 hover:border-accent/50 transition-colors">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <Image
                    src={testimonial?.avatar}
                    alt={testimonial?.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="font-medium text-foreground">{testimonial?.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {testimonial?.role} • {testimonial?.company}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      {renderStars(testimonial?.rating)}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    {testimonial?.content}
                  </p>
                  <div className="flex items-center space-x-2">
                    <Icon name="Briefcase" size={14} className="text-accent" />
                    <span className="text-xs text-accent font-medium">
                      Projeto: {testimonial?.project}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Certifications */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <h3 className="text-lg font-heading font-bold text-foreground mb-6">
          Certificações Profissionais
        </h3>
        
        <div className="space-y-4">
          {certifications?.map((cert, index) => (
            <div key={index} className="flex items-center space-x-4 p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors">
              <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                <Icon name={cert?.icon} size={20} className="text-accent" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-foreground">{cert?.name}</h4>
                <p className="text-sm text-muted-foreground">
                  {cert?.issuer} • {cert?.year}
                </p>
              </div>
              <Icon name="ExternalLink" size={16} className="text-muted-foreground" />
            </div>
          ))}
        </div>
      </div>
      {/* GitHub Activity */}
      <div className="bg-card rounded-2xl p-6 shadow-brand border border-border">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-heading font-bold text-foreground">
            Atividade no GitHub
          </h3>
          <button
            onClick={() => window.open('https://github.com/techfolio-pro', '_blank')}
            className="text-accent hover:text-accent/80 transition-colors"
          >
            <Icon name="ExternalLink" size={20} />
          </button>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Repositórios Públicos:</span>
            <span className="font-medium text-foreground">42</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Contribuições (2024):</span>
            <span className="font-medium text-foreground">1,247</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Seguidores:</span>
            <span className="font-medium text-foreground">156</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Linguagens Principais:</span>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">JavaScript</span>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">TypeScript</span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">Python</span>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Código aberto ativo com contribuições regulares para projetos da comunidade React e Node.js.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SocialProof;