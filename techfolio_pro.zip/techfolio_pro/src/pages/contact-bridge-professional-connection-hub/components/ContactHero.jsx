import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ContactHero = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Simulate online status
    const onlineTimer = setInterval(() => {
      setIsOnline(Math.random() > 0.1); // 90% chance of being online
    }, 30000);

    return () => {
      clearInterval(timer);
      clearInterval(onlineTimer);
    };
  }, []);

  const formatTime = (date) => {
    return date?.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'America/Sao_Paulo'
    });
  };

  const getGreeting = () => {
    const hour = currentTime?.getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  const quickActions = [
    {
      icon: 'MessageCircle',
      label: 'Chat Rápido',
      description: 'WhatsApp Business',
      action: () => window.open('https://wa.me/5511999998888', '_blank'),
      color: 'bg-green-500'
    },
    {
      icon: 'Calendar',
      label: 'Agendar Reunião',
      description: '30 min gratuitos',
      action: () => window.open('https://calendly.com/techfolio-pro/30min', '_blank'),
      color: 'bg-blue-500'
    },
    {
      icon: 'Mail',
      label: 'Email Direto',
      description: 'Resposta em 24h',
      action: () => window.open('mailto:contato@techfolio.dev', '_blank'),
      color: 'bg-accent'
    }
  ];

  return (
    <div className="relative overflow-hidden bg-gradient-brand rounded-3xl p-8 lg:p-12 text-white">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-20 h-20 border border-white/20 rounded-full"></div>
        <div className="absolute top-32 right-20 w-16 h-16 border border-white/20 rounded-full"></div>
        <div className="absolute bottom-20 left-32 w-12 h-12 border border-white/20 rounded-full"></div>
        <div className="absolute bottom-32 right-10 w-24 h-24 border border-white/20 rounded-full"></div>
      </div>
      <div className="relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="flex-1 mb-8 lg:mb-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center space-x-3 mb-4">
                <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-green-400' : 'bg-gray-400'} animate-pulse`}></div>
                <span className="text-sm font-medium opacity-90">
                  {isOnline ? 'Online agora' : 'Offline'} • {formatTime(currentTime)} (GMT-3)
                </span>
              </div>

              <h1 className="text-4xl lg:text-5xl font-heading font-bold mb-4">
                {getGreeting()}! 👋
              </h1>
              
              <h2 className="text-2xl lg:text-3xl font-heading font-semibold mb-6 opacity-90">
                Vamos Transformar Sua Ideia em Realidade
              </h2>
              
              <p className="text-lg opacity-80 mb-8 max-w-2xl leading-relaxed">
                Seja para desenvolver uma aplicação web moderna, criar uma API robusta, ou implementar uma solução completa, 
                estou aqui para ajudar você a alcançar seus objetivos tecnológicos com excelência e inovação.
              </p>

              <div className="flex flex-wrap gap-4">
                <Button
                  variant="secondary"
                  size="lg"
                  onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
                  iconName="ArrowDown"
                  iconPosition="right"
                  className="bg-white text-brand-primary hover:bg-gray-100"
                >
                  Iniciar Conversa
                </Button>
                
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => window.open('/assets/cv/TechFolio-Pro-CV-2024.pdf', '_blank')}
                  iconName="Download"
                  iconPosition="left"
                  className="border-white text-white hover:bg-white/10"
                >
                  Baixar CV
                </Button>
              </div>
            </motion.div>
          </div>

          <div className="lg:ml-12">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20"
            >
              <h3 className="text-lg font-semibold mb-4">Ações Rápidas</h3>
              
              <div className="space-y-3">
                {quickActions?.map((action, index) => (
                  <motion.button
                    key={index}
                    onClick={action?.action}
                    className="w-full flex items-center space-x-4 p-3 rounded-xl bg-white/10 hover:bg-white/20 transition-all duration-200 hover-lift"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className={`w-10 h-10 ${action?.color} rounded-lg flex items-center justify-center`}>
                      <Icon name={action?.icon} size={20} className="text-white" />
                    </div>
                    <div className="flex-1 text-left">
                      <div className="font-medium">{action?.label}</div>
                      <div className="text-sm opacity-70">{action?.description}</div>
                    </div>
                    <Icon name="ExternalLink" size={16} className="opacity-70" />
                  </motion.button>
                ))}
              </div>

              <div className="mt-6 pt-4 border-t border-white/20">
                <div className="flex items-center space-x-2 text-sm opacity-80">
                  <Icon name="Clock" size={16} />
                  <span>Horário comercial: 9h às 18h (GMT-3)</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Floating Elements */}
        <motion.div
          className="absolute top-4 right-4 lg:top-8 lg:right-8"
          animate={{ 
            y: [0, -10, 0],
            rotate: [0, 5, 0]
          }}
          transition={{ 
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-sm">
            <Icon name="Code" size={24} className="text-accent" />
          </div>
        </motion.div>

        <motion.div
          className="absolute bottom-4 left-4 lg:bottom-8 lg:left-8"
          animate={{ 
            y: [0, 10, 0],
            rotate: [0, -5, 0]
          }}
          transition={{ 
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        >
          <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center backdrop-blur-sm">
            <Icon name="Zap" size={20} className="text-accent" />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ContactHero;