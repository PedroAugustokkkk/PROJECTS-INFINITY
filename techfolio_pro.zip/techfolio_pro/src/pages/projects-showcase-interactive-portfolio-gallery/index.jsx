import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import ProjectCard from './components/ProjectCard';
import ProjectFilter from './components/ProjectFilter';
import ProjectStats from './components/ProjectStats';
import FeaturedProject from './components/FeaturedProject';

const ProjectsShowcase = () => {
  const [activeFilter, setActiveFilter] = useState('all');

  // Mock project data
  const projects = [
    {
      id: 1,
      title: "E-commerce Marketplace Brasil",
      description: "Plataforma completa de e-commerce com integração de pagamentos, gestão de estoque e painel administrativo avançado.",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=600&fit=crop",
      category: "fullstack",
      type: "Web Application",
      status: "Concluído",
      duration: "4 meses",
      teamSize: "3 devs",
      impact: "+150%",
      technologies: ["React", "Node.js", "PostgreSQL", "Stripe", "AWS"],
      demoUrl: "https://demo-ecommerce.com",
      githubUrl: "https://github.com/user/ecommerce",
      problem: `O cliente precisava de uma solução robusta para vender produtos online no mercado brasileiro, com integração completa de pagamentos PIX, cartão e boleto, além de gestão automatizada de estoque e relatórios de vendas em tempo real.`,
      approach: `Desenvolvemos uma arquitetura em microserviços usando React no frontend e Node.js no backend, com PostgreSQL para dados transacionais e Redis para cache. Implementamos integração com APIs do Mercado Pago e PagSeguro para pagamentos locais.`,
      features: [
        "Catálogo de produtos com busca avançada",
        "Carrinho de compras persistente",
        "Checkout com múltiplas formas de pagamento",
        "Painel administrativo completo",
        "Sistema de avaliações e comentários",
        "Integração com correios para frete",
        "Relatórios de vendas em tempo real",
        "Sistema de cupons e promoções"
      ],
      results: `Aumento de 150% nas vendas online nos primeiros 3 meses, redução de 40% no tempo de processamento de pedidos e 95% de satisfação dos usuários com a nova interface.`,
      codeSnippet: `// Integração com API de pagamentos
const processPayment = async (paymentData) => {
  try {
    const response = await mercadoPago.payment.create({
      transaction_amount: paymentData.amount,
      payment_method_id: paymentData.method,
      payer: paymentData.payer
    });
    return response.body;
  } catch (error) {
    throw new Error('Erro no processamento');
  }
};`
    },
    {
      id: 2,
      title: "Sistema de Gestão Hospitalar",
      description: "Aplicação web para gestão completa de hospitais com módulos de pacientes, médicos, agendamentos e prontuários eletrônicos.",
      image: "https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?w=800&h=600&fit=crop",
      category: "frontend",
      type: "Healthcare System",
      status: "Concluído",
      duration: "6 meses",
      teamSize: "5 devs",
      impact: "+200%",
      technologies: ["React", "TypeScript", "Material-UI", "Chart.js"],
      demoUrl: "https://demo-hospital.com",
      githubUrl: "https://github.com/user/hospital",
      problem: `Hospital precisava digitalizar processos manuais de agendamento, prontuários em papel e controle de medicamentos, reduzindo erros médicos e melhorando eficiência operacional.`,
      approach: `Criamos uma SPA em React com TypeScript para type safety, usando Material-UI para interface consistente e Chart.js para dashboards médicos. Implementamos PWA para acesso offline em tablets.`,
      features: [
        "Cadastro e gestão de pacientes",
        "Agendamento de consultas online",
        "Prontuário eletrônico completo",
        "Controle de medicamentos",
        "Dashboard médico com métricas",
        "Sistema de notificações",
        "Relatórios gerenciais",
        "Integração com equipamentos médicos"
      ],
      results: `Redução de 60% no tempo de atendimento, eliminação de 100% dos prontuários em papel e aumento de 200% na satisfação dos pacientes com o novo sistema de agendamento online.`,
      codeSnippet: `// Hook customizado para gestão de pacientes
const usePatients = () => {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const addPatient = useCallback(async (data) => {
    setLoading(true);
    try {
      const response = await api.post('/patients', data);
      setPatients(prev => [...prev, response.data]);
    } finally {
      setLoading(false);
    }
  }, []);
  
  return { patients, addPatient, loading };
};`
    },
    {
      id: 3,
      title: "App Mobile de Delivery",
      description: "Aplicativo móvel para delivery de comida com geolocalização, pagamentos integrados e sistema de avaliações.",
      image: "https://images.pixabay.com/photo/2017/03/29/04/47/delivery-2184491_1280.jpg?w=800&h=600&fit=crop",
      category: "mobile",
      type: "Mobile App",
      status: "Em Desenvolvimento",
      duration: "3 meses",
      teamSize: "4 devs",
      impact: "Em análise",
      technologies: ["React Native", "Firebase", "Google Maps", "Stripe"],
      demoUrl: null,
      githubUrl: "https://github.com/user/delivery-app",
      problem: `Restaurantes locais precisavam de uma solução mobile para delivery que competisse com grandes players, oferecendo experiência personalizada e taxas menores.`,
      approach: `Desenvolvemos em React Native para iOS e Android, usando Firebase para backend-as-a-service, Google Maps para geolocalização e Stripe para pagamentos internacionais.`,
      features: [
        "Catálogo de restaurantes por região",
        "Busca por tipo de comida",
        "Carrinho com personalização de pedidos",
        "Rastreamento em tempo real",
        "Sistema de avaliações",
        "Programa de fidelidade",
        "Notificações push",
        "Chat com entregador"
      ],
      results: `Projeto em desenvolvimento com previsão de lançamento para Q2 2024. Testes beta mostram 4.8 estrelas de satisfação e tempo médio de entrega 25% menor que concorrentes.`,
      codeSnippet: `// Componente de rastreamento de pedido
const OrderTracking = ({ orderId }) => {
  const [location, setLocation] = useState(null);
  
  useEffect(() => {
    const unsubscribe = firestore()
      .collection('orders')
      .doc(orderId)
      .onSnapshot(doc => {
        setLocation(doc.data().deliveryLocation);
      });
    
    return unsubscribe;
  }, [orderId]);
  
  return (
    <MapView region={location}>
      <Marker coordinate={location} />
    </MapView>
  );
};`
    },
    {
      id: 4,
      title: "Dashboard Analytics B2B",
      description: "Plataforma de analytics para empresas com visualizações interativas, relatórios automatizados e integração com múltiplas fontes de dados.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
      category: "backend",
      type: "Analytics Platform",
      status: "Concluído",
      duration: "5 meses",
      teamSize: "6 devs",
      impact: "+300%",
      technologies: ["Python", "Django", "PostgreSQL", "Redis", "Docker"],
      demoUrl: "https://demo-analytics.com",
      githubUrl: "https://github.com/user/analytics",
      problem: `Empresas precisavam consolidar dados de vendas, marketing e operações em uma única plataforma, com relatórios automatizados e insights acionáveis para tomada de decisão.`,
      approach: `Construímos uma API robusta em Django com PostgreSQL para dados estruturados, Redis para cache e Celery para processamento assíncrono. Docker para containerização e deploy escalável.`,
      features: [
        "Integração com múltiplas APIs",
        "Dashboards personalizáveis",
        "Relatórios automatizados",
        "Alertas inteligentes",
        "Exportação de dados",
        "API REST completa",
        "Sistema de permissões",
        "Backup automatizado"
      ],
      results: `Aumento de 300% na velocidade de geração de relatórios, redução de 80% no tempo gasto em análise manual e ROI de 250% no primeiro ano de uso.`,
      codeSnippet: `# Sistema de cache inteligente
from django.core.cache import cache
from django.db.models.signals import post_save

class AnalyticsService:
    @staticmethod
    def get_dashboard_data(user_id, date_range):
        cache_key = f"dashboard_{user_id}_{date_range}"
        data = cache.get(cache_key)
        
        if not data:
            data = Analytics.objects.filter(
                user_id=user_id,
                created_at__range=date_range
            ).aggregate_metrics()
            cache.set(cache_key, data, 3600)
        
        return data`
    },
    {
      id: 5,
      title: "Plataforma de Educação Online",
      description: "Sistema completo de EAD com videoaulas, exercícios interativos, gamificação e acompanhamento de progresso.",
      image: "https://images.pexels.com/photos/4144923/pexels-photo-4144923.jpeg?w=800&h=600&fit=crop",
      category: "fullstack",
      type: "Education Platform",
      status: "Concluído",
      duration: "8 meses",
      teamSize: "7 devs",
      impact: "+400%",
      technologies: ["Vue.js", "Laravel", "MySQL", "WebRTC", "AWS S3"],
      demoUrl: "https://demo-education.com",
      githubUrl: "https://github.com/user/education",
      problem: `Instituição de ensino precisava migrar para formato híbrido pós-pandemia, oferecendo experiência de aprendizado engajante com acompanhamento personalizado do progresso dos alunos.`,
      approach: `Desenvolvemos em Vue.js com Laravel no backend, MySQL para dados relacionais, WebRTC para videoconferências e AWS S3 para armazenamento de conteúdo multimídia.`,
      features: [
        "Streaming de videoaulas HD",
        "Exercícios interativos",
        "Sistema de gamificação",
        "Fóruns de discussão",
        "Videoconferências ao vivo",
        "Certificados digitais",
        "Relatórios de progresso",
        "App mobile companion"
      ],
      results: `Aumento de 400% no engajamento dos alunos, 95% de conclusão dos cursos online e redução de 50% nos custos operacionais da instituição.`,
      codeSnippet: `// Sistema de gamificação
class GamificationService {
  static calculatePoints(activity) {
    const pointsMap = {
      'video_completed': 10,
      'exercise_correct': 5,
      'forum_participation': 3,
      'streak_bonus': 20
    };
    
    return pointsMap[activity.type] || 0;
  }
  
  static updateUserLevel(userId, points) {
    const user = User.find(userId);
    user.points += points;
    user.level = Math.floor(user.points / 100);
    user.save();
  }
}`
    },
    {
      id: 6,
      title: "API de Microserviços Financeiros",
      description: "Arquitetura de microserviços para sistema financeiro com alta disponibilidade, segurança avançada e processamento em tempo real.",
      image: "https://images.pixabay.com/photo/2018/03/22/02/37/email-3249062_1280.png?w=800&h=600&fit=crop",
      category: "backend",
      type: "Microservices API",
      status: "Concluído",
      duration: "10 meses",
      teamSize: "8 devs",
      impact: "+500%",
      technologies: ["Node.js", "MongoDB", "RabbitMQ", "Docker", "Kubernetes"],
      demoUrl: null,
      githubUrl: "https://github.com/user/fintech-api",
      problem: `Fintech precisava de arquitetura escalável para processar milhões de transações diárias com latência mínima, alta disponibilidade e conformidade com regulamentações bancárias.`,
      approach: `Implementamos microserviços em Node.js com MongoDB para dados não-relacionais, RabbitMQ para mensageria assíncrona e Kubernetes para orquestração de containers.`,
      features: [
        "Processamento de transações em tempo real",
        "Sistema de autenticação JWT",
        "Auditoria completa de operações",
        "Rate limiting inteligente",
        "Monitoramento com Prometheus",
        "Circuit breaker pattern",
        "Backup automático",
        "Compliance PCI DSS"
      ],
      results: `Processamento de 5 milhões de transações/dia com 99.9% de uptime, redução de 70% na latência de resposta e conformidade total com regulamentações do Banco Central.`,
      codeSnippet: `// Circuit breaker para resiliência
class CircuitBreaker {
  constructor(threshold = 5, timeout = 60000) {
    this.failureCount = 0;
    this.threshold = threshold;
    this.timeout = timeout;
    this.state = 'CLOSED';
  }
  
  async call(fn) {
    if (this.state === 'OPEN') {
      throw new Error('Circuit breaker is OPEN');
    }
    
    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }
}`
    }
  ];

  // Featured project (first project)
  const featuredProject = {
    ...projects?.[0],
    category: "Destaque",
    overview: `Este projeto representa a evolução do e-commerce brasileiro, combinando as melhores práticas de UX/UI com tecnologias modernas para criar uma experiência de compra excepcional. Desenvolvido com foco na realidade do mercado nacional, incluindo integração nativa com PIX, boleto bancário e principais gateways de pagamento locais.`,
    architecture: `Arquitetura em microserviços com React no frontend, Node.js/Express no backend, PostgreSQL para dados transacionais e Redis para cache. Deploy automatizado na AWS com CI/CD via GitHub Actions.`,
    achievements: [
      "Aumento de 150% nas conversões de venda",
      "Redução de 40% no tempo de carregamento das páginas",
      "95% de satisfação dos usuários finais",
      "Integração completa com 5 gateways de pagamento",
      "Sistema de recomendações com 85% de precisão"
    ]
  };

  // Project categories
  const categories = [
    { key: 'fullstack', label: 'Full-Stack', icon: 'Layers' },
    { key: 'frontend', label: 'Frontend', icon: 'Monitor' },
    { key: 'backend', label: 'Backend', icon: 'Server' },
    { key: 'mobile', label: 'Mobile', icon: 'Smartphone' }
  ];

  // Project statistics
  const projectStats = {
    completed: 12,
    inProgress: 3,
    clients: 25,
    technologies: 18
  };

  // Filter projects based on active filter
  const filteredProjects = useMemo(() => {
    if (activeFilter === 'all') {
      return projects;
    }
    return projects?.filter(project => project?.category === activeFilter);
  }, [activeFilter, projects]);

  // Count projects by category
  const projectCounts = useMemo(() => {
    const counts = {};
    categories?.forEach(category => {
      counts[category.key] = projects?.filter(p => p?.category === category?.key)?.length;
    });
    return counts;
  }, [projects, categories]);

  const handleFilterChange = (filter) => {
    setActiveFilter(filter);
  };

  const handleContactClick = () => {
    window.location.href = '/contact-bridge-professional-connection-hub';
  };

  return (
    <>
      <Helmet>
        <title>Projetos - Portfolio Interativo | TechFolio Pro</title>
        <meta name="description" content="Explore meu portfólio de projetos de desenvolvimento web, mobile e sistemas. Casos de estudo detalhados com tecnologias modernas e resultados comprovados." />
        <meta name="keywords" content="projetos, portfolio, desenvolvimento web, React, Node.js, mobile, full-stack" />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        {/* Hero Section */}
        <section className="pt-24 pb-16 px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <div className="inline-flex items-center space-x-2 bg-accent/10 text-accent px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Icon name="FolderOpen" size={16} />
                <span>Portfolio de Projetos</span>
              </div>
              
              <h1 className="text-4xl lg:text-6xl font-heading font-bold text-foreground mb-6">
                Projetos que
                <span className="block text-accent">Transformam Ideias</span>
                em Realidade
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-8">
                Explore uma coleção cuidadosamente selecionada de projetos que demonstram 
                expertise técnica, pensamento estratégico e impacto real no mundo dos negócios.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  variant="default"
                  size="lg"
                  onClick={handleContactClick}
                  iconName="MessageCircle"
                  iconPosition="left"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Vamos Conversar
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => window.open('https://github.com', '_blank')}
                  iconName="Github"
                  iconPosition="left"
                >
                  Ver no GitHub
                </Button>
              </div>
            </motion.div>

            {/* Project Statistics */}
            <ProjectStats stats={projectStats} />
          </div>
        </section>

        {/* Featured Project */}
        <section className="pb-16 px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <FeaturedProject project={featuredProject} />
          </div>
        </section>

        {/* Projects Gallery */}
        <section className="pb-20 px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            {/* Section Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl lg:text-4xl font-heading font-bold text-foreground mb-4">
                Todos os Projetos
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Cada projeto conta uma história única de desafios superados e soluções inovadoras
              </p>
            </motion.div>

            {/* Project Filter */}
            <ProjectFilter
              categories={categories}
              activeFilter={activeFilter}
              onFilterChange={handleFilterChange}
              projectCounts={projectCounts}
            />

            {/* Projects Grid */}
            <motion.div
              layout
              className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8"
            >
              {filteredProjects?.map((project, index) => (
                <ProjectCard
                  key={project?.id}
                  project={project}
                  index={index}
                />
              ))}
            </motion.div>

            {/* Empty State */}
            {filteredProjects?.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-16"
              >
                <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                  <Icon name="Search" size={32} className="text-muted-foreground" />
                </div>
                <h3 className="text-xl font-heading font-semibold text-foreground mb-2">
                  Nenhum projeto encontrado
                </h3>
                <p className="text-muted-foreground mb-6">
                  Tente ajustar os filtros ou explore todas as categorias
                </p>
                <Button
                  variant="outline"
                  onClick={() => handleFilterChange('all')}
                  iconName="RotateCcw"
                  iconPosition="left"
                >
                  Limpar Filtros
                </Button>
              </motion.div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6 lg:px-8 bg-gradient-brand">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl lg:text-4xl font-heading font-bold text-white mb-6">
                Pronto para Criar Algo Incrível Juntos?
              </h2>
              <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
                Cada projeto é uma oportunidade de transformar desafios em soluções inovadoras. 
                Vamos conversar sobre como posso ajudar a materializar sua próxima grande ideia.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button
                  variant="default"
                  size="lg"
                  onClick={handleContactClick}
                  iconName="ArrowRight"
                  iconPosition="right"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Iniciar Conversa
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => window.location.href = '/skills-matrix-dynamic-technical-capabilities'}
                  iconName="Code"
                  iconPosition="left"
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  Ver Habilidades
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ProjectsShowcase;