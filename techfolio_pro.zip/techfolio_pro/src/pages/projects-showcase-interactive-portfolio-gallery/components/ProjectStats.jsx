import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const ProjectStats = ({ stats }) => {
  const statItems = [
    {
      icon: 'Code',
      label: 'Projetos Concluídos',
      value: stats?.completed,
      color: 'text-success'
    },
    {
      icon: 'Clock',
      label: 'Em Desenvolvimento',
      value: stats?.inProgress,
      color: 'text-warning'
    },
    {
      icon: 'Users',
      label: 'Clientes Atendidos',
      value: stats?.clients,
      color: 'text-accent'
    },
    {
      icon: 'Star',
      label: 'Tecnologias Dominadas',
      value: stats?.technologies,
      color: 'text-primary'
    }
  ];

  return (
    <div className="mb-12">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statItems?.map((stat, index) => (
          <motion.div
            key={stat?.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-card rounded-xl p-6 text-center shadow-soft border border-border hover-lift transition-all duration-300"
          >
            <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-muted mb-3 ${stat?.color}`}>
              <Icon name={stat?.icon} size={24} />
            </div>
            <div className="text-2xl font-bold text-foreground mb-1">
              {stat?.value}
            </div>
            <div className="text-sm text-muted-foreground font-medium">
              {stat?.label}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ProjectStats;