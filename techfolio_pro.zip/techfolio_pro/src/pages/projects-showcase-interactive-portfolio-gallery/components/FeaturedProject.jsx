import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const FeaturedProject = ({ project }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { key: 'overview', label: 'Visão Geral', icon: 'Eye' },
    { key: 'technical', label: 'Detalhes Técnicos', icon: 'Code' },
    { key: 'results', label: 'Resultados', icon: 'TrendingUp' }
  ];

  const handleDemoClick = () => {
    if (project?.demoUrl) {
      window.open(project?.demoUrl, '_blank');
    }
  };

  const handleGithubClick = () => {
    if (project?.githubUrl) {
      window.open(project?.githubUrl, '_blank');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="mb-16 bg-gradient-brand rounded-2xl overflow-hidden shadow-brand-hover"
    >
      {/* Featured Badge */}
      <div className="bg-accent text-accent-foreground px-6 py-3 text-center">
        <div className="flex items-center justify-center space-x-2">
          <Icon name="Star" size={20} />
          <span className="font-heading font-bold">Projeto em Destaque</span>
          <Icon name="Star" size={20} />
        </div>
      </div>
      <div className="bg-card">
        <div className="grid lg:grid-cols-2 gap-0">
          {/* Project Image */}
          <div className="relative h-64 lg:h-auto">
            <Image
              src={project?.image}
              alt={project?.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent lg:hidden" />
            
            {/* Mobile Title Overlay */}
            <div className="absolute bottom-4 left-4 lg:hidden">
              <h2 className="text-2xl font-heading font-bold text-white mb-1">
                {project?.title}
              </h2>
              <p className="text-white/80 text-sm">{project?.category}</p>
            </div>
          </div>

          {/* Project Content */}
          <div className="p-8">
            {/* Desktop Title */}
            <div className="hidden lg:block mb-6">
              <div className="flex items-center space-x-2 mb-2">
                <span className="px-3 py-1 bg-accent text-accent-foreground text-xs rounded-full font-medium">
                  {project?.category}
                </span>
                <span className="px-3 py-1 bg-success text-success-foreground text-xs rounded-full font-medium">
                  {project?.status}
                </span>
              </div>
              <h2 className="text-3xl font-heading font-bold text-foreground mb-2">
                {project?.title}
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                {project?.description}
              </p>
            </div>

            {/* Tab Navigation */}
            <div className="flex space-x-1 mb-6 bg-muted rounded-lg p-1">
              {tabs?.map((tab) => (
                <button
                  key={tab?.key}
                  onClick={() => setActiveTab(tab?.key)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 flex-1 justify-center ${
                    activeTab === tab?.key
                      ? 'bg-background text-foreground shadow-soft'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon name={tab?.icon} size={16} />
                  <span className="hidden sm:inline">{tab?.label}</span>
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="mb-6">
              {activeTab === 'overview' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h3 className="font-heading font-semibold text-foreground mb-3">
                    Sobre o Projeto
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                    {project?.overview}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Duração</div>
                      <div className="font-semibold text-foreground">{project?.duration}</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Equipe</div>
                      <div className="font-semibold text-foreground">{project?.teamSize}</div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'technical' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h3 className="font-heading font-semibold text-foreground mb-3">
                    Stack Tecnológico
                  </h3>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project?.technologies?.map((tech, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-brand-primary text-white text-xs rounded-full font-medium"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  
                  <h4 className="font-semibold text-foreground mb-2">Arquitetura</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {project?.architecture}
                  </p>
                </motion.div>
              )}

              {activeTab === 'results' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h3 className="font-heading font-semibold text-foreground mb-3">
                    Impacto e Resultados
                  </h3>
                  <div className="space-y-3">
                    {project?.achievements?.map((achievement, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className="w-6 h-6 bg-success/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Icon name="Check" size={14} className="text-success" />
                        </div>
                        <p className="text-muted-foreground text-sm leading-relaxed">
                          {achievement}
                        </p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              {project?.demoUrl && (
                <Button
                  variant="default"
                  onClick={handleDemoClick}
                  iconName="ExternalLink"
                  iconPosition="left"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Ver Demo
                </Button>
              )}
              {project?.githubUrl && (
                <Button
                  variant="outline"
                  onClick={handleGithubClick}
                  iconName="Github"
                  iconPosition="left"
                >
                  Código Fonte
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default FeaturedProject;