import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const ProjectFilter = ({ categories, activeFilter, onFilterChange, projectCounts }) => {
  const filterButtons = [
    { key: 'all', label: 'Todos os Projetos', icon: 'Grid3X3' },
    ...categories?.map(category => ({
      key: category?.key,
      label: category?.label,
      icon: category?.icon
    }))
  ];

  return (
    <div className="mb-8">
      {/* Filter Title */}
      <div className="text-center mb-6">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
          Filtrar por Categoria
        </h3>
        <p className="text-muted-foreground text-sm">
          Explore projetos organizados por tecnologia e tipo
        </p>
      </div>
      {/* Filter Buttons - Desktop */}
      <div className="hidden md:flex flex-wrap justify-center gap-3">
        {filterButtons?.map((filter, index) => {
          const count = filter?.key === 'all' 
            ? Object.values(projectCounts)?.reduce((sum, count) => sum + count, 0)
            : projectCounts?.[filter?.key] || 0;

          return (
            <motion.button
              key={filter?.key}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              onClick={() => onFilterChange(filter?.key)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium text-sm transition-all duration-200 hover-lift ${
                activeFilter === filter?.key
                  ? 'bg-accent text-accent-foreground shadow-soft'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground'
              }`}
            >
              <Icon name={filter?.icon} size={16} />
              <span>{filter?.label}</span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                activeFilter === filter?.key
                  ? 'bg-accent-foreground/20 text-accent-foreground'
                  : 'bg-background text-muted-foreground'
              }`}>
                {count}
              </span>
            </motion.button>
          );
        })}
      </div>
      {/* Filter Buttons - Mobile Dropdown */}
      <div className="md:hidden">
        <div className="relative">
          <select
            value={activeFilter}
            onChange={(e) => onFilterChange(e?.target?.value)}
            className="w-full px-4 py-3 bg-muted border border-border rounded-lg text-foreground font-medium appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
          >
            {filterButtons?.map((filter) => {
              const count = filter?.key === 'all' 
                ? Object.values(projectCounts)?.reduce((sum, count) => sum + count, 0)
                : projectCounts?.[filter?.key] || 0;
              
              return (
                <option key={filter?.key} value={filter?.key}>
                  {filter?.label}({count})
                                  </option>
              );
            })}
          </select>
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
            <Icon name="ChevronDown" size={20} className="text-muted-foreground" />
          </div>
        </div>
      </div>
      {/* Active Filter Indicator */}
      {activeFilter !== 'all' && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-center justify-center mt-4"
        >
          <div className="flex items-center space-x-2 px-3 py-1 bg-accent/10 text-accent rounded-full text-sm">
            <Icon name="Filter" size={14} />
            <span>
              Mostrando: {filterButtons?.find(f => f?.key === activeFilter)?.label}
            </span>
            <button
              onClick={() => onFilterChange('all')}
              className="ml-1 p-0.5 hover:bg-accent/20 rounded-full transition-colors"
              title="Limpar filtro"
            >
              <Icon name="X" size={12} />
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default ProjectFilter;