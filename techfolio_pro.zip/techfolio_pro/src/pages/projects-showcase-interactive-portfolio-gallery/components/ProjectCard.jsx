import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ProjectCard = ({ project, index }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleToggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const handleDemoClick = () => {
    if (project?.demoUrl) {
      window.open(project?.demoUrl, '_blank');
    }
  };

  const handleGithubClick = () => {
    if (project?.githubUrl) {
      window.open(project?.githubUrl, '_blank');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className={`bg-card rounded-xl shadow-brand border border-border overflow-hidden hover-lift transition-all duration-300 ${
        isExpanded ? 'col-span-full lg:col-span-2' : ''
      }`}
    >
      {/* Project Image */}
      <div className="relative h-48 lg:h-56 overflow-hidden">
        <Image
          src={project?.image}
          alt={project?.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        
        {/* Status Badge */}
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            project?.status === 'Concluído' 
              ? 'bg-success text-success-foreground' 
              : project?.status === 'Em Desenvolvimento' ?'bg-warning text-warning-foreground' :'bg-accent text-accent-foreground'
          }`}>
            {project?.status}
          </span>
        </div>

        {/* Quick Actions */}
        <div className="absolute top-4 right-4 flex space-x-2">
          {project?.demoUrl && (
            <button
              onClick={handleDemoClick}
              className="p-2 bg-background/80 backdrop-blur-sm rounded-lg hover:bg-background transition-colors"
              title="Ver Demo"
            >
              <Icon name="ExternalLink" size={16} />
            </button>
          )}
          {project?.githubUrl && (
            <button
              onClick={handleGithubClick}
              className="p-2 bg-background/80 backdrop-blur-sm rounded-lg hover:bg-background transition-colors"
              title="Ver Código"
            >
              <Icon name="Github" size={16} />
            </button>
          )}
        </div>

        {/* Project Type */}
        <div className="absolute bottom-4 left-4">
          <span className="px-2 py-1 bg-brand-primary text-white text-xs rounded-md font-medium">
            {project?.type}
          </span>
        </div>
      </div>
      {/* Project Content */}
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-xl font-heading font-bold text-foreground mb-2">
              {project?.title}
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              {project?.description}
            </p>
          </div>
          <button
            onClick={handleToggleExpanded}
            className="ml-4 p-2 rounded-lg hover:bg-muted transition-colors"
            title={isExpanded ? 'Recolher' : 'Expandir'}
          >
            <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={20} />
          </button>
        </div>

        {/* Technology Stack */}
        <div className="flex flex-wrap gap-2 mb-4">
          {project?.technologies?.map((tech, techIndex) => (
            <span
              key={techIndex}
              className="px-3 py-1 bg-muted text-muted-foreground text-xs rounded-full font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
            >
              {tech}
            </span>
          ))}
        </div>

        {/* Project Metrics */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center">
            <div className="text-lg font-bold text-foreground">{project?.duration}</div>
            <div className="text-xs text-muted-foreground">Duração</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-foreground">{project?.teamSize}</div>
            <div className="text-xs text-muted-foreground">Equipe</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-accent">{project?.impact}</div>
            <div className="text-xs text-muted-foreground">Impacto</div>
          </div>
        </div>

        {/* Expanded Content */}
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="border-t border-border pt-4 mt-4"
          >
            {/* Problem Statement */}
            <div className="mb-6">
              <h4 className="font-heading font-semibold text-foreground mb-2 flex items-center">
                <Icon name="Target" size={16} className="mr-2 text-accent" />
                Problema Resolvido
              </h4>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {project?.problem}
              </p>
            </div>

            {/* Technical Approach */}
            <div className="mb-6">
              <h4 className="font-heading font-semibold text-foreground mb-2 flex items-center">
                <Icon name="Code" size={16} className="mr-2 text-accent" />
                Abordagem Técnica
              </h4>
              <p className="text-muted-foreground text-sm leading-relaxed mb-3">
                {project?.approach}
              </p>
              
              {/* Code Snippet Preview */}
              {project?.codeSnippet && (
                <div className="bg-muted rounded-lg p-4 font-mono text-sm overflow-x-auto">
                  <pre className="text-foreground whitespace-pre-wrap">
                    {project?.codeSnippet}
                  </pre>
                </div>
              )}
            </div>

            {/* Key Features */}
            <div className="mb-6">
              <h4 className="font-heading font-semibold text-foreground mb-3 flex items-center">
                <Icon name="Star" size={16} className="mr-2 text-accent" />
                Principais Funcionalidades
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {project?.features?.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center text-sm">
                    <Icon name="Check" size={14} className="mr-2 text-success flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Results */}
            <div className="mb-6">
              <h4 className="font-heading font-semibold text-foreground mb-2 flex items-center">
                <Icon name="TrendingUp" size={16} className="mr-2 text-accent" />
                Resultados Alcançados
              </h4>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {project?.results}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              {project?.demoUrl && (
                <Button
                  variant="default"
                  onClick={handleDemoClick}
                  iconName="ExternalLink"
                  iconPosition="left"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Ver Demo Ao Vivo
                </Button>
              )}
              {project?.githubUrl && (
                <Button
                  variant="outline"
                  onClick={handleGithubClick}
                  iconName="Github"
                  iconPosition="left"
                >
                  Ver Código Fonte
                </Button>
              )}
              {project?.caseStudyUrl && (
                <Button
                  variant="ghost"
                  onClick={() => window.open(project?.caseStudyUrl, '_blank')}
                  iconName="FileText"
                  iconPosition="left"
                >
                  Estudo de Caso Completo
                </Button>
              )}
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default ProjectCard;