import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/ui/Header';
import HeroSection from './components/HeroSection';
import FloatingNavigation from './components/FloatingNavigation';
import QuickPreviewSection from './components/QuickPreviewSection';
import InteractiveShowcase from './components/InteractiveShowcase';

const HomepageInteractiveItPortfolio = () => {
  const handleNavigation = (path) => {
    window.location.href = path;
  };

  useEffect(() => {
    // Smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Add scroll-triggered animations
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
        }
      });
    }, observerOptions);

    // Observe all sections
    const sections = document.querySelectorAll('section[data-section]');
    sections?.forEach((section) => observer?.observe(section));

    // Performance optimization
    const handleScroll = () => {
      const scrolled = window.pageYOffset;
      const parallaxElements = document.querySelectorAll('[data-parallax]');
      
      parallaxElements?.forEach((element) => {
        const speed = element?.dataset?.parallax || 0.5;
        const yPos = -(scrolled * speed);
        element.style.transform = `translateY(${yPos}px)`;
      });
    };

    // Throttled scroll handler
    let ticking = false;
    const throttledScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          handleScroll();
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', throttledScroll, { passive: true });

    // Cleanup
    return () => {
      observer?.disconnect();
      window.removeEventListener('scroll', throttledScroll);
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  const pageVariants = {
    initial: { opacity: 0 },
    animate: { 
      opacity: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    },
    exit: { 
      opacity: 0,
      transition: {
        duration: 0.3
      }
    }
  };

  return (
    <motion.div
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className="min-h-screen bg-background"
    >
      {/* Header */}
      <Header />
      {/* Floating Navigation */}
      <FloatingNavigation onNavigate={handleNavigation} />
      {/* Main Content */}
      <main className="relative">
        {/* Hero Section */}
        <HeroSection onNavigate={handleNavigation} />

        {/* Quick Preview Section */}
        <QuickPreviewSection onNavigate={handleNavigation} />

        {/* Interactive Showcase */}
        <InteractiveShowcase onNavigate={handleNavigation} />

        {/* Background Decorative Elements */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
          {/* Animated Gradient Orbs */}
          <motion.div
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3]
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-brand-primary/5 rounded-full blur-3xl"
            animate={{
              scale: [1.2, 1, 1.2],
              opacity: [0.2, 0.4, 0.2]
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 2
            }}
          />
        </div>
      </main>
      {/* Performance Monitoring */}
      <div className="fixed bottom-4 right-4 z-50 opacity-0 hover:opacity-100 transition-opacity duration-300">
        <div className="bg-card/90 backdrop-blur-sm border border-border rounded-lg p-2 text-xs text-muted-foreground font-mono">
          <div>FPS: {Math.round(60)}</div>
          <div>Load: {new Date()?.toLocaleTimeString('pt-BR')}</div>
        </div>
      </div>
    </motion.div>
  );
};

export default HomepageInteractiveItPortfolio;