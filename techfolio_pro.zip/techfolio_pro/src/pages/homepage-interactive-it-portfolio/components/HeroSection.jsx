import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HeroSection = ({ onNavigate }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e?.clientX / window.innerWidth) * 100,
        y: (e?.clientY / window.innerHeight) * 100
      });
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      clearInterval(timer);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const nameLetters = "TechFolio Pro"?.split("");
  const taglineWords = ["Criando", "soluções", "digitais", "que", "transformam", "ideias", "em", "realidade"];

  const letterVariants = {
    hidden: { opacity: 0, y: 50, rotateX: -90 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      rotateX: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.8,
        ease: [0.6, -0.05, 0.01, 0.99]
      }
    })
  };

  const wordVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 1.5 + i * 0.2,
        duration: 0.6,
        ease: "easeOut"
      }
    })
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };

  const floatingVariants = {
    animate: {
      y: [-20, 20, -20],
      rotate: [0, 5, -5, 0],
      transition: {
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-brand-primary via-brand-secondary to-brand-primary">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        {/* Floating Geometric Shapes */}
        <motion.div
          className="absolute top-20 left-10 w-20 h-20 border-2 border-accent/30 rounded-lg"
          variants={floatingVariants}
          animate="animate"
        />
        <motion.div
          className="absolute top-40 right-20 w-16 h-16 bg-accent/20 rounded-full"
          variants={floatingVariants}
          animate="animate"
          style={{ animationDelay: '2s' }}
        />
        <motion.div
          className="absolute bottom-40 left-20 w-12 h-12 border-2 border-accent/40 rotate-45"
          variants={floatingVariants}
          animate="animate"
          style={{ animationDelay: '4s' }}
        />

        {/* Interactive Mouse Parallax */}
        <motion.div
          className="absolute inset-0 opacity-30"
          animate={{
            background: `radial-gradient(circle at ${mousePosition?.x}% ${mousePosition?.y}%, rgba(255, 195, 0, 0.1) 0%, transparent 50%)`
          }}
          transition={{ duration: 0.3 }}
        />

        {/* Grid Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="w-full h-full" style={{
            backgroundImage: `linear-gradient(rgba(255, 195, 0, 0.1) 1px, transparent 1px),
                             linear-gradient(90deg, rgba(255, 195, 0, 0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px'
          }} />
        </div>
      </div>
      {/* Main Content */}
      <div className="relative z-10 text-center px-6 max-w-6xl mx-auto">
        {/* Status Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="inline-flex items-center space-x-2 bg-accent/20 backdrop-blur-sm border border-accent/30 rounded-full px-4 py-2 mb-8"
        >
          <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
          <span className="text-accent text-sm font-medium">
            Disponível para novos projetos
          </span>
          <span className="text-accent/70 text-xs">
            {currentTime?.toLocaleTimeString('pt-BR', { 
              hour: '2-digit', 
              minute: '2-digit',
              timeZone: 'America/Sao_Paulo'
            })} BRT
          </span>
        </motion.div>

        {/* Animated Name */}
        <div className="mb-6">
          <motion.h1
            className="text-5xl md:text-7xl lg:text-8xl font-heading font-bold text-white leading-tight"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {nameLetters?.map((letter, index) => (
              <motion.span
                key={index}
                className={`inline-block ${letter === ' ' ? 'w-4' : ''} ${
                  ['T', 'P']?.includes(letter) ? 'text-accent' : 'text-white'
                }`}
                variants={letterVariants}
                custom={index}
                style={{ transformOrigin: '50% 100%' }}
              >
                {letter === ' ' ? '\u00A0' : letter}
              </motion.span>
            ))}
          </motion.h1>
        </div>

        {/* Animated Tagline */}
        <div className="mb-8">
          <div className="flex flex-wrap justify-center gap-2 text-xl md:text-2xl lg:text-3xl text-white/90 font-light">
            {taglineWords?.map((word, index) => (
              <motion.span
                key={index}
                variants={wordVariants}
                custom={index}
                initial="hidden"
                animate="visible"
                className="inline-block"
              >
                {word}
              </motion.span>
            ))}
          </div>
        </div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 3, duration: 0.8 }}
          className="text-lg md:text-xl text-white/80 mb-12 max-w-3xl mx-auto leading-relaxed"
        >
          Desenvolvedor Full-Stack especializado em React, Node.js e arquiteturas modernas. 
          Transformo conceitos complexos em experiências digitais intuitivas e performáticas.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 3.5, duration: 0.8 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <Button
            variant="default"
            size="lg"
            onClick={() => onNavigate('/projects-showcase-interactive-portfolio-gallery')}
            iconName="FolderOpen"
            iconPosition="left"
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-8 py-4 hover-scale"
          >
            Ver Projetos
          </Button>
          <Button
            variant="outline"
            size="lg"
            onClick={() => onNavigate('/contact-bridge-professional-connection-hub')}
            iconName="MessageCircle"
            iconPosition="left"
            className="border-white/30 text-white hover:bg-white/10 px-8 py-4 hover-lift"
          >
            Vamos Conversar
          </Button>
        </motion.div>

        {/* Tech Stack Preview */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4, duration: 0.8 }}
          className="mt-16 pt-8 border-t border-white/20"
        >
          <p className="text-white/60 text-sm mb-4 font-medium">
            Tecnologias Principais
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            {[
              { name: 'React', icon: 'Code' },
              { name: 'Node.js', icon: 'Server' },
              { name: 'TypeScript', icon: 'FileCode' },
              { name: 'PostgreSQL', icon: 'Database' },
              { name: 'AWS', icon: 'Cloud' },
              { name: 'Docker', icon: 'Package' }
            ]?.map((tech, index) => (
              <motion.div
                key={tech?.name}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 4.2 + index * 0.1, duration: 0.5 }}
                className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-lg px-3 py-2 hover:bg-white/20 transition-colors cursor-pointer"
              >
                <Icon name={tech?.icon} size={16} className="text-accent" />
                <span className="text-white/90 text-sm font-medium">{tech?.name}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 5, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="flex flex-col items-center space-y-2">
          <span className="text-white/60 text-xs font-medium">Explore a jornada</span>
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center"
          >
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              className="w-1 h-3 bg-accent rounded-full mt-2"
            />
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;