import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const QuickPreviewSection = ({ onNavigate }) => {
  const [hoveredCard, setHoveredCard] = useState(null);
  const [currentStats, setCurrentStats] = useState({
    projects: 0,
    experience: 0,
    technologies: 0,
    clients: 0
  });

  const finalStats = {
    projects: 47,
    experience: 5,
    technologies: 23,
    clients: 12
  };

  useEffect(() => {
    const animateStats = () => {
      const duration = 2000;
      const steps = 60;
      const stepDuration = duration / steps;

      let step = 0;
      const timer = setInterval(() => {
        step++;
        const progress = step / steps;
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);

        setCurrentStats({
          projects: Math.round(finalStats?.projects * easeOutQuart),
          experience: Math.round(finalStats?.experience * easeOutQuart),
          technologies: Math.round(finalStats?.technologies * easeOutQuart),
          clients: Math.round(finalStats?.clients * easeOutQuart)
        });

        if (step >= steps) {
          clearInterval(timer);
        }
      }, stepDuration);

      return () => clearInterval(timer);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            animateStats();
          }
        });
      },
      { threshold: 0.5 }
    );

    const element = document.getElementById('stats-section');
    if (element) {
      observer?.observe(element);
    }

    return () => {
      if (element) {
        observer?.unobserve(element);
      }
    };
  }, []);

  const previewCards = [
    {
      id: 'about',
      title: 'Sobre Mim',
      description: 'Conheça minha jornada como desenvolvedor e minha paixão por tecnologia',
      icon: 'User',
      path: '/about-section-professional-brand-story',
      gradient: 'from-blue-600 to-blue-800',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop&crop=face',
      stats: 'Desenvolvedor há 5+ anos'
    },
    {
      id: 'projects',
      title: 'Projetos',
      description: 'Explore uma seleção dos meus trabalhos mais impactantes e inovadores',
      icon: 'FolderOpen',
      path: '/projects-showcase-interactive-portfolio-gallery',
      gradient: 'from-purple-600 to-purple-800',
      image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=300&fit=crop',
      stats: '47+ projetos concluídos'
    },
    {
      id: 'skills',
      title: 'Habilidades',
      description: 'Descubra as tecnologias e ferramentas que domino profissionalmente',
      icon: 'Code',
      path: '/skills-matrix-dynamic-technical-capabilities',
      gradient: 'from-green-600 to-green-800',
      image: 'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400&h=300&fit=crop',
      stats: '23+ tecnologias'
    },
    {
      id: 'contact',
      title: 'Contato',
      description: 'Vamos conversar sobre seu próximo projeto ou oportunidade',
      icon: 'Mail',
      path: '/contact-bridge-professional-connection-hub',
      gradient: 'from-orange-600 to-orange-800',
      image: 'https://images.unsplash.com/photo-1423666639041-f56000c27a9a?w=400&h=300&fit=crop',
      stats: 'Resposta em 24h'
    }
  ];

  const statsData = [
    {
      label: 'Projetos',
      value: currentStats?.projects,
      suffix: '+',
      icon: 'FolderOpen',
      color: 'text-blue-400'
    },
    {
      label: 'Anos de Experiência',
      value: currentStats?.experience,
      suffix: '+',
      icon: 'Calendar',
      color: 'text-green-400'
    },
    {
      label: 'Tecnologias',
      value: currentStats?.technologies,
      suffix: '+',
      icon: 'Code',
      color: 'text-purple-400'
    },
    {
      label: 'Clientes Satisfeitos',
      value: currentStats?.clients,
      suffix: '+',
      icon: 'Users',
      color: 'text-orange-400'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 50, scale: 0.9 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: [0.6, -0.05, 0.01, 0.99]
      }
    }
  };

  const statVariants = {
    hidden: { opacity: 0, scale: 0.5 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5,
        ease: "backOut"
      }
    }
  };

  return (
    <section className="py-20 bg-gradient-to-b from-brand-surface to-background" data-section="preview">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-6">
            Explore Minha
            <span className="text-accent ml-3">Jornada</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Uma visão completa das minhas habilidades, projetos e experiências que definem 
            minha carreira como desenvolvedor full-stack
          </p>
        </motion.div>

        {/* Stats Section */}
        <motion.div
          id="stats-section"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20"
        >
          {statsData?.map((stat, index) => (
            <motion.div
              key={stat?.label}
              variants={statVariants}
              initial="hidden"
              whileInView="visible"
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="text-center p-6 bg-card rounded-xl shadow-soft border border-border hover:shadow-brand transition-all duration-300 hover-lift"
            >
              <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-muted mb-4 ${stat?.color}`}>
                <Icon name={stat?.icon} size={24} />
              </div>
              <div className="text-3xl font-bold text-foreground mb-2">
                {stat?.value}{stat?.suffix}
              </div>
              <div className="text-sm text-muted-foreground font-medium">
                {stat?.label}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Preview Cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {previewCards?.map((card, index) => (
            <motion.div
              key={card?.id}
              variants={cardVariants}
              className="group relative overflow-hidden rounded-2xl bg-card border border-border shadow-soft hover:shadow-brand transition-all duration-500 hover-lift cursor-pointer"
              onMouseEnter={() => setHoveredCard(card?.id)}
              onMouseLeave={() => setHoveredCard(null)}
              onClick={() => onNavigate(card?.path)}
            >
              {/* Background Image */}
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={card?.image}
                  alt={card?.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${card?.gradient} opacity-80 group-hover:opacity-70 transition-opacity duration-300`} />
                
                {/* Floating Icon */}
                <motion.div
                  animate={{
                    y: hoveredCard === card?.id ? -5 : 0,
                    rotate: hoveredCard === card?.id ? 5 : 0
                  }}
                  transition={{ duration: 0.3 }}
                  className="absolute top-6 right-6 w-12 h-12 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center border border-white/30"
                >
                  <Icon name={card?.icon} size={24} className="text-white" />
                </motion.div>

                {/* Stats Badge */}
                <div className="absolute bottom-4 left-4 bg-black/30 backdrop-blur-sm rounded-lg px-3 py-1 border border-white/20">
                  <span className="text-white text-sm font-medium">{card?.stats}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-2xl font-heading font-bold text-foreground mb-3 group-hover:text-accent transition-colors">
                  {card?.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  {card?.description}
                </p>

                {/* CTA Button */}
                <Button
                  variant="outline"
                  size="sm"
                  iconName="ArrowRight"
                  iconPosition="right"
                  className="group-hover:bg-accent group-hover:text-accent-foreground group-hover:border-accent transition-all duration-300"
                >
                  Explorar
                </Button>
              </div>

              {/* Hover Effect Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: hoveredCard === card?.id ? 1 : 0 }}
                className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent pointer-events-none"
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="inline-flex items-center space-x-4 bg-card rounded-2xl p-6 shadow-soft border border-border">
            <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center">
              <Icon name="Rocket" size={24} className="text-accent" />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-semibold text-foreground">
                Pronto para começar um projeto?
              </h3>
              <p className="text-muted-foreground text-sm">
                Vamos transformar suas ideias em realidade digital
              </p>
            </div>
            <Button
              variant="default"
              onClick={() => onNavigate('/contact-bridge-professional-connection-hub')}
              iconName="MessageCircle"
              iconPosition="left"
              className="bg-accent hover:bg-accent/90 text-accent-foreground hover-scale"
            >
              Falar Agora
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default QuickPreviewSection;