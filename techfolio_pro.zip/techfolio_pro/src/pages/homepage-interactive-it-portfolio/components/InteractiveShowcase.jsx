import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const InteractiveShowcase = ({ onNavigate }) => {
  const [activeDemo, setActiveDemo] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const showcaseItems = [
    {
      id: 'ecommerce',
      title: 'E-commerce Moderno',
      description: 'Plataforma completa com React, Node.js e PostgreSQL. Interface responsiva com carrinho inteligente e pagamentos integrados.',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=600&fit=crop',
      technologies: ['React', 'Node.js', 'PostgreSQL', 'Stripe'],
      metrics: {
        performance: 95,
        users: '10K+',
        conversion: '12.5%'
      },
      features: [
        'Carrinho inteligente com recomendações',
        'Sistema de pagamentos seguro',
        'Dashboard administrativo completo',
        'API RESTful otimizada'
      ],
      color: '#3B82F6'
    },
    {
      id: 'dashboard',
      title: 'Dashboard Analytics',
      description: 'Sistema de análise de dados em tempo real com visualizações interativas e relatórios automatizados.',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop',
      technologies: ['React', 'D3.js', 'Express', 'MongoDB'],
      metrics: {
        performance: 98,
        users: '5K+',
        dataPoints: '1M+'
      },
      features: [
        'Gráficos interativos em tempo real',
        'Filtros avançados e drill-down',
        'Exportação de relatórios',
        'Alertas personalizáveis'
      ],
      color: '#10B981'
    },
    {
      id: 'mobile',
      title: 'App Mobile Híbrido',
      description: 'Aplicativo cross-platform com React Native, oferecendo experiência nativa em iOS e Android.',
      image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&h=600&fit=crop',
      technologies: ['React Native', 'Firebase', 'Redux', 'Expo'],
      metrics: {
        performance: 92,
        downloads: '25K+',
        rating: '4.8★'
      },
      features: [
        'Interface nativa otimizada',
        'Sincronização offline',
        'Push notifications',
        'Integração com APIs nativas'
      ],
      color: '#8B5CF6'
    }
  ];

  useEffect(() => {
    let interval;
    if (isAutoPlaying) {
      interval = setInterval(() => {
        setActiveDemo((prev) => (prev + 1) % showcaseItems?.length);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isAutoPlaying, showcaseItems?.length]);

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e?.clientX / window.innerWidth) * 100,
        y: (e?.clientY / window.innerHeight) * 100
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const currentItem = showcaseItems?.[activeDemo];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: [0.6, -0.05, 0.01, 0.99]
      }
    }
  };

  const slideVariants = {
    enter: (direction) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1
    },
    exit: (direction) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8
    })
  };

  const handleDemoChange = (index) => {
    setActiveDemo(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  return (
    <section className="py-20 bg-gradient-to-br from-background via-brand-surface to-background overflow-hidden" data-section="showcase">
      {/* Interactive Background */}
      <div className="absolute inset-0 opacity-30">
        <motion.div
          className="absolute inset-0"
          animate={{
            background: `radial-gradient(circle at ${mousePosition?.x}% ${mousePosition?.y}%, ${currentItem?.color}20 0%, transparent 50%)`
          }}
          transition={{ duration: 0.3 }}
        />
      </div>
      <div className="relative max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.h2
            variants={itemVariants}
            className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-6"
          >
            Projetos em
            <span className="text-accent ml-3">Destaque</span>
          </motion.h2>
          <motion.p
            variants={itemVariants}
            className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed"
          >
            Explore alguns dos meus trabalhos mais impactantes, cada um demonstrando 
            diferentes aspectos da minha expertise técnica
          </motion.p>
        </motion.div>

        {/* Main Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Demo Navigation & Info */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {/* Demo Selector */}
            <div className="space-y-4">
              {showcaseItems?.map((item, index) => (
                <motion.button
                  key={item?.id}
                  onClick={() => handleDemoChange(index)}
                  className={`w-full text-left p-4 rounded-xl border transition-all duration-300 ${
                    activeDemo === index
                      ? 'bg-card border-accent shadow-brand'
                      : 'bg-card/50 border-border hover:border-accent/50 hover:bg-card'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-12 h-12 rounded-lg flex items-center justify-center transition-colors ${
                        activeDemo === index ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      <Icon 
                        name={item?.id === 'ecommerce' ? 'ShoppingCart' : item?.id === 'dashboard' ? 'BarChart3' : 'Smartphone'} 
                        size={24} 
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className={`font-semibold transition-colors ${
                        activeDemo === index ? 'text-foreground' : 'text-muted-foreground'
                      }`}>
                        {item?.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {item?.description?.substring(0, 60)}...
                      </p>
                    </div>
                    {activeDemo === index && (
                      <motion.div
                        layoutId="activeIndicator"
                        className="w-2 h-8 bg-accent rounded-full"
                      />
                    )}
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Current Project Details */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeDemo}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="bg-card rounded-xl p-6 border border-border shadow-soft"
              >
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  {currentItem?.title}
                </h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {currentItem?.description}
                </p>

                {/* Technologies */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-foreground mb-3">
                    Tecnologias Utilizadas
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {currentItem?.technologies?.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-lg font-medium"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Features */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-foreground mb-3">
                    Principais Funcionalidades
                  </h4>
                  <ul className="space-y-2">
                    {currentItem?.features?.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <Icon name="Check" size={16} className="text-accent flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {Object.entries(currentItem?.metrics)?.map(([key, value]) => (
                    <div key={key} className="text-center">
                      <div className="text-2xl font-bold text-foreground">{value}</div>
                      <div className="text-xs text-muted-foreground capitalize">{key}</div>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <Button
                  variant="default"
                  onClick={() => onNavigate('/projects-showcase-interactive-portfolio-gallery')}
                  iconName="ExternalLink"
                  iconPosition="right"
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Ver Projeto Completo
                </Button>
              </motion.div>
            </AnimatePresence>
          </motion.div>

          {/* Visual Demo */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative h-96 lg:h-[500px] rounded-2xl overflow-hidden shadow-brand">
              <AnimatePresence mode="wait" custom={activeDemo}>
                <motion.div
                  key={activeDemo}
                  custom={activeDemo}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{
                    x: { type: "spring", stiffness: 300, damping: 30 },
                    opacity: { duration: 0.2 }
                  }}
                  className="absolute inset-0"
                >
                  <Image
                    src={currentItem?.image}
                    alt={currentItem?.title}
                    className="w-full h-full object-cover"
                  />
                  <div 
                    className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"
                    style={{ backgroundColor: `${currentItem?.color}20` }}
                  />
                </motion.div>
              </AnimatePresence>

              {/* Progress Indicators */}
              <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {showcaseItems?.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => handleDemoChange(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      activeDemo === index ? 'bg-accent scale-125' : 'bg-white/50 hover:bg-white/70'
                    }`}
                  />
                ))}
              </div>

              {/* Auto-play Control */}
              <button
                onClick={() => setIsAutoPlaying(!isAutoPlaying)}
                className="absolute top-6 right-6 w-10 h-10 bg-black/30 backdrop-blur-sm rounded-lg flex items-center justify-center text-white hover:bg-black/50 transition-colors"
              >
                <Icon name={isAutoPlaying ? 'Pause' : 'Play'} size={16} />
              </button>
            </div>

            {/* Floating Elements */}
            <motion.div
              animate={{
                y: [0, -10, 0],
                rotate: [0, 5, -5, 0]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute -top-4 -right-4 w-20 h-20 bg-accent/20 rounded-full border-2 border-accent/30"
            />
            <motion.div
              animate={{
                y: [0, 15, 0],
                rotate: [0, -5, 5, 0]
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
              className="absolute -bottom-6 -left-6 w-16 h-16 bg-brand-primary/20 rounded-lg border-2 border-brand-primary/30"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveShowcase;