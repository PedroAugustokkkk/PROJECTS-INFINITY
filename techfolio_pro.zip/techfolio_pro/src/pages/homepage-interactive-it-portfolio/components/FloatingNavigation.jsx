import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const FloatingNavigation = ({ onNavigate }) => {
  const [activeSection, setActiveSection] = useState(0);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const navigationItems = [
    { 
      name: 'Início', 
      path: '/homepage-interactive-it-portfolio', 
      icon: 'Home',
      color: '#FFC300'
    },
    { 
      name: 'Sobre', 
      path: '/about-section-professional-brand-story', 
      icon: 'User',
      color: '#FFD60A'
    },
    { 
      name: 'Projetos', 
      path: '/projects-showcase-interactive-portfolio-gallery', 
      icon: 'FolderOpen',
      color: '#FFC300'
    },
    { 
      name: 'Habilidades', 
      path: '/skills-matrix-dynamic-technical-capabilities', 
      icon: 'Code',
      color: '#FFD60A'
    },
    { 
      name: 'Contato', 
      path: '/contact-bridge-professional-connection-hub', 
      icon: 'Mail',
      color: '#FFC300'
    }
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset;
      const docHeight = document.documentElement?.scrollHeight - window.innerHeight;
      const progress = (scrollTop / docHeight) * 100;
      setScrollProgress(progress);

      // Determine active section based on scroll position
      const sections = document.querySelectorAll('section[data-section]');
      let currentSection = 0;
      
      sections?.forEach((section, index) => {
        const rect = section?.getBoundingClientRect();
        if (rect?.top <= window.innerHeight / 2 && rect?.bottom >= window.innerHeight / 2) {
          currentSection = index;
        }
      });
      
      setActiveSection(currentSection);
    };

    const handleMouseMove = (e) => {
      // Hide navigation when mouse is near the left edge
      setIsVisible(e?.clientX > 100);
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('mousemove', handleMouseMove);
    handleScroll(); // Initial call

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const navVariants = {
    hidden: { x: -100, opacity: 0 },
    visible: { 
      x: 0, 
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 15
      }
    }
  };

  const itemVariants = {
    inactive: { 
      scale: 0.8, 
      opacity: 0.6,
      x: 0
    },
    active: { 
      scale: 1.2, 
      opacity: 1,
      x: 10,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    },
    hover: { 
      scale: 1.1, 
      x: 8,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 25
      }
    }
  };

  const progressVariants = {
    initial: { height: 0 },
    animate: { 
      height: `${scrollProgress}%`,
      transition: {
        duration: 0.1,
        ease: "easeOut"
      }
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          variants={navVariants}
          initial="hidden"
          animate="visible"
          exit="hidden"
          className="fixed left-6 top-1/2 transform -translate-y-1/2 z-50"
        >
          {/* Navigation Container */}
          <div className="relative">
            {/* Progress Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-0.5 h-64 bg-white/20 rounded-full">
              <motion.div
                variants={progressVariants}
                initial="initial"
                animate="animate"
                className="w-full bg-gradient-to-b from-accent to-accent/60 rounded-full origin-top"
              />
            </div>

            {/* Navigation Items */}
            <div className="relative flex flex-col items-center space-y-6 py-4">
              {navigationItems?.map((item, index) => (
                <motion.div
                  key={item?.path}
                  className="relative group"
                  variants={itemVariants}
                  initial="inactive"
                  animate={activeSection === index ? "active" : "inactive"}
                  whileHover="hover"
                >
                  <button
                    onClick={() => onNavigate(item?.path)}
                    className="relative w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center transition-all duration-300 hover:bg-white/20 hover:border-accent/50"
                    style={{
                      boxShadow: activeSection === index 
                        ? `0 0 20px ${item?.color}40` 
                        : 'none'
                    }}
                  >
                    <Icon 
                      name={item?.icon} 
                      size={20} 
                      className={`transition-colors duration-300 ${
                        activeSection === index ? 'text-accent' : 'text-white/70'
                      }`}
                    />
                    
                    {/* Active Indicator */}
                    {activeSection === index && (
                      <motion.div
                        layoutId="activeIndicator"
                        className="absolute inset-0 rounded-full border-2 border-accent"
                        initial={false}
                        transition={{
                          type: "spring",
                          stiffness: 500,
                          damping: 30
                        }}
                      />
                    )}
                  </button>

                  {/* Tooltip */}
                  <motion.div
                    initial={{ opacity: 0, x: -10, scale: 0.8 }}
                    whileHover={{ opacity: 1, x: 0, scale: 1 }}
                    className="absolute left-16 top-1/2 transform -translate-y-1/2 bg-brand-primary/90 backdrop-blur-sm text-white px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap border border-accent/20 pointer-events-none"
                  >
                    {item?.name}
                    <div className="absolute left-0 top-1/2 transform -translate-x-1 -translate-y-1/2 w-2 h-2 bg-brand-primary/90 rotate-45 border-l border-b border-accent/20" />
                  </motion.div>
                </motion.div>
              ))}
            </div>

            {/* Scroll Progress Indicator */}
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 }}
              className="absolute -bottom-8 left-1/2 transform -translate-x-1/2"
            >
              <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center">
                <span className="text-xs text-white/70 font-mono">
                  {Math.round(scrollProgress)}%
                </span>
              </div>
            </motion.div>
          </div>

          {/* Floating Action Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5 }}
            className="absolute -bottom-20 left-1/2 transform -translate-x-1/2"
          >
            <button
              onClick={() => onNavigate('/contact-bridge-professional-connection-hub')}
              className="w-14 h-14 rounded-full bg-accent hover:bg-accent/90 text-accent-foreground shadow-brand-hover flex items-center justify-center transition-all duration-300 hover-scale group"
            >
              <Icon name="MessageCircle" size={24} className="group-hover:scale-110 transition-transform" />
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default FloatingNavigation;